INSERT INTO USER (email,gender,online_status,PASSWORD,phone_number,profession,user_name) VALUES
("a1@gmail.com","Male","Offline","User123@","1111111111","Artist","a1"),
("a2@gmail.com","FeMale","Offline","User123@","2222222222","Organiser","a2"),
("a3@gmail.com","Male","Offline","User123@","3333333333","Artist","a3"),
("a4@gmail.com","FeMale","Offline","User123@","4444444444","Organiser","a4"),
("a5@gmail.com","Male","Offline","User123@","5555555555","Artist","a5"),
("a6@gmail.com","FeMale","Offline","User123@","6666666666","Organiser","a6"),
("a7@gmail.com","Male","Offline","User123@","7777777777","Artist","a7"),
("a8@gmail.com","FeMale","Offline","User123@","8888888888","Organiser","a8"),
("a9@gmail.com","Male","Offline","User123@","9999999999","Artist","a9"),
("a10@gmail.com","FeMale","Offline","User123@","1010101010","Organiser","a10");

INSERT INTO follower (followed_user_id_user_id,following_user_id_user_id) VALUES
(1,3),(1,5),(1,7),(1,9),(2,4),(2,6),(2,8),(2,10),(3,1),(3,5),(3,7),(3,9),(4,6),(4,8),(4,10),(6,8),(6,10),(7,9),(8,10);

INSERT INTO news_feed (post,user_user_id) VALUES
("hello,I am user 1",1),
("hello,I am user 1 again",1),
("hello,I am user 2",2),
("hello,I am user 3",3),
("hello,I am user 4",4),
("hello,I am user 5",5),
("hello,I am user 6",6),
("hello,I am user 7",7),
("hello,I am user 8",8),
("hello,I am user 9",9),
("hello,I am user 10",10);

INSERT INTO like_dislike (dislike_status,like_status,news_feed_news_feed_id,user_user_id) VALUES
("NO","YES",2,1),
("YES","NO",2,2),
("YES","NO",1,2),
("NO","YES",2,3),
("NO","YES",5,7),
("YES","NO",2,7),
("YES","NO",2,9);

INSERT INTO COMMENT (COMMENT,news_feed_news_feed_id,user_user_id) VALUES
("Nice Post",2,1),
("Worst Post",2,2),
("Nice Post",3,3),
("Worst Post",3,1),
("Nice Post",6,3),
("Worst Post",6,4),
("Nice Post",7,9),
("Worst Post",7,9);

INSERT INTO project (file_name,FORMAT,STATUS,user_user_id) VALUES
("img1.jpeg","jpeg","Uploaded",1),
("img2.jpeg","jpeg","Uploaded",2),
("img3.png","png","Uploaded",3),
("img4.jpeg","jpeg","Uploaded",4),
("img5.png","png","Uploaded",5),
("img6.jpeg","jpeg","Uploaded",6),
("img7.png","png","Uploaded",7),
("img8.jpeg","jpeg","Uploaded",8),
("img9.png","png","Uploaded",9),
("img10.jpeg","jpeg","Uploaded",10);














