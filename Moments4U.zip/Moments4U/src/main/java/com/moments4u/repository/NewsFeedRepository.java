package com.moments4u.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.moments4u.entities.NewsFeed;

@Repository
public interface NewsFeedRepository extends JpaRepository<NewsFeed, Integer> {

	List<NewsFeed> findByUser_UserIdOrderByDateTimeDesc(Integer userId);

	NewsFeed findByNewsFeedId(Integer newsFeedId);


}
