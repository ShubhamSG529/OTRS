package com.moments4u.exception;

public class InvalidGenderTypeException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidGenderTypeException(String msg) {
		super(msg);
	}
}
