package com.moments4u.controllers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.dto.ProjectDto;
import com.moments4u.entities.ErrorDetails;
import com.moments4u.entities.NewsFeed;
import com.moments4u.entities.User;
import com.moments4u.exception.DuplicateEmailException;
import com.moments4u.exception.DuplicatePhoneNumberException;
import com.moments4u.exception.InvalidEmailFormatException;
import com.moments4u.exception.InvalidGenderTypeException;
import com.moments4u.exception.InvalidOnlineStatusTypeException;
import com.moments4u.exception.InvalidPasswordFormatException;
import com.moments4u.exception.InvalidPhoneNumberException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.InvalidUserNameException;
import com.moments4u.service.NewsFeedService;
import com.moments4u.service.ProjectService;
import com.moments4u.service.Test;
import com.moments4u.service.UploadFileService;
import com.moments4u.service.UserService;

@RestController
@CrossOrigin
public class Controllers implements ErrorController {
	@Autowired
	UserService userService;

	@Autowired
	NewsFeedService newsFeedService;

	@Autowired
	ProjectService projectService;

	@Autowired
	UploadFileService uploadFileService;

	@Autowired
	Test testService;

	@RequestMapping("/error")
	public String handleError(HttpServletRequest request, HttpServletResponse response) {

		final Integer STATUS_CODE = response.getStatus();
		final Date CURRENT_TIME = new Date();

		String htmlError = "<!DOCTYPE html><html><style>body,html {height: 100%;margin: 0;}.bgimg {background-image: url('error.jpg');height: 100%;"
				+ "background-position: center;background-size: cover;position: relative;color: white;font-family: 'Courier New', Courier, monospace;"
				+ "font-size: 25px;}.topleft {position: absolute;top: 0;left: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".topright {position: absolute;right: 0;margin-right: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".bottomleft {position: absolute;bottom: 0;left: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".bottomright {position: absolute;bottom: 0;right: 0;margin-right: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".middle {position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;}"
				+ "hr {margin: auto;width: 60%;}</style><body><div class='bgimg'><div class='topleft'><p>ERROR PAGE</p></div><div class='topright'><p>STATUS : "
				+ STATUS_CODE
				+ "</p></div><div class='middle'><h1>SOMETHING WENT WRONG !!!</h1><h1>WE ARE WORKING ON IT</h1></div><div class='bottomleft'><p>"
				+ CURRENT_TIME + "</p>"
				+ "</div><div class='bottomright'><p>INTERNAL SERVER ERROR</p></div></div></body></html>";

		return htmlError;
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
		System.out.println("!! handleAllExceptions !!");

		ErrorDetails errorDetails = new ErrorDetails();
		errorDetails.setMessage(ex.getMessage());
		errorDetails.setException(ex.getClass().toString());
		errorDetails.setStatus("500");

		return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> signup(@RequestBody User user)
			throws DuplicateEmailException, DuplicatePhoneNumberException, InvalidPhoneNumberException,
			InvalidGenderTypeException, InvalidOnlineStatusTypeException, InvalidUserNameException,
			InvalidEmailFormatException, InvalidPasswordFormatException {

		if (userService.signupUser(user) != null)
			return new ResponseEntity<String>("SUCCESSFULLY REGISTERED", HttpStatus.ACCEPTED);// #202
		else
			return new ResponseEntity<String>("NOT REGISTERED SOMETHING WENT WRONG", HttpStatus.NOT_ACCEPTABLE);// #406
	}

	@RequestMapping(value = "/signin", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> signin(@RequestBody User user) throws InvalidUserDetailsException {
		if (userService.signinUser(user) != null)
			return new ResponseEntity<String>("SUCCESSFULLY SIGNIN", HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<String>("SOMETHING WENT WRONG", HttpStatus.NOT_ACCEPTABLE);
	}

	@RequestMapping(value = "/all_news_feed", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<NewsFeedDto>> allNewsFeedByUserId(@RequestBody User user)
			throws InvalidUserDetailsException {

		List<NewsFeedDto> newsFeeds = newsFeedService.getAllNewsFeeds(user.getUserId());
		if (newsFeeds != null) {
			return new ResponseEntity<List<NewsFeedDto>>(newsFeeds, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<List<NewsFeedDto>>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@RequestMapping(value = "/projects", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProjectDto>> allProjects() {
		List<ProjectDto> projects = projectService.getAllProjects();
		if (projects != null) {
			return new ResponseEntity<List<ProjectDto>>(projects, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<List<ProjectDto>>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@RequestMapping(value = "/post_newsfeed", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NewsFeed> addNewsFeeds(@RequestBody NewsFeed newsFeed)
			throws InvalidUserDetailsException, Exception {

		NewsFeed addedNewsFeed = newsFeedService.postNewsFeed(newsFeed);

		return new ResponseEntity<NewsFeed>(addedNewsFeed, HttpStatus.ACCEPTED);// #202
	}

	@RequestMapping(value = "/update_profile", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> updateUserProfile(@RequestBody User user) throws InvalidUserDetailsException {
		User updatedUser = userService.updateUserProfile(user);
		if (updatedUser != null) {
			return new ResponseEntity<User>(updatedUser, HttpStatus.ACCEPTED);// #202
		} else {
			return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);// #406
		}
	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = "multipart/form-data", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> uploadVideoImages(@RequestParam("img") MultipartFile file)
			throws FileNotFoundException, IOException {
		String result = uploadFileService.upload(file);

		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/test")
	public void testMethod() {
		testService.test();
	}
}
