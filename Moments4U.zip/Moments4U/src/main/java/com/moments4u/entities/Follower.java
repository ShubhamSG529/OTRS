package com.moments4u.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Follower {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer followerId;

	@ManyToOne
	private User followingUserId;

	@ManyToOne
	private User followedUserId;

	public Integer getFollowerId() {
		return followerId;
	}

	public void setFollowerId(Integer followerId) {
		this.followerId = followerId;
	}

	public User getFollowingUserId() {
		return followingUserId;
	}

	public void setFollowingUserId(User followingUserId) {
		this.followingUserId = followingUserId;
	}

	public User getFollowedUserId() {
		return followedUserId;
	}

	public void setFollowedUserId(User followedUserId) {
		this.followedUserId = followedUserId;
	}

	@Override
	public String toString() {
		return "Follower [followerId=" + followerId + ", followingUserId=" + followingUserId + ", followedUserId="
				+ followedUserId + "]";
	}

}
