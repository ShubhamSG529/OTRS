package com.moments4u.entities;

import java.sql.Timestamp;

public class ErrorDetails {

	private Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
	private String status;
	private String exception;
	private String message;

	public ErrorDetails() {
		super();
	}

	public ErrorDetails(String status, String exception, String message) {
		super();
		this.status = status;
		this.exception = exception;
		this.message = message;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ErrorDetails [timeStamp=" + timeStamp + ", status=" + status + ", exception=" + exception + ", message="
				+ message + "]";
	}

}
