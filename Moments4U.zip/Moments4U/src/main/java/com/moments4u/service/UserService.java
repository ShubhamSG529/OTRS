package com.moments4u.service;

import com.moments4u.entities.User;
import com.moments4u.exception.DuplicateEmailException;
import com.moments4u.exception.DuplicatePhoneNumberException;
import com.moments4u.exception.InvalidEmailFormatException;
import com.moments4u.exception.InvalidGenderTypeException;
import com.moments4u.exception.InvalidOnlineStatusTypeException;
import com.moments4u.exception.InvalidPasswordFormatException;
import com.moments4u.exception.InvalidPhoneNumberException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.InvalidUserNameException;

public interface UserService {

	User signupUser(User user) throws DuplicateEmailException, DuplicatePhoneNumberException, InvalidPhoneNumberException, InvalidGenderTypeException, InvalidOnlineStatusTypeException, InvalidUserNameException, InvalidEmailFormatException, InvalidPasswordFormatException;

	User signinUser(User user) throws InvalidUserDetailsException;

	User updateUserProfile(User user) throws InvalidUserDetailsException;

}
