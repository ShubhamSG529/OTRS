package com.moments4u.service;

import java.util.List;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.entities.NewsFeed;
import com.moments4u.exception.InvalidUserDetailsException;

public interface NewsFeedService {

	List<NewsFeedDto> getAllNewsFeeds(Integer userId) throws InvalidUserDetailsException;

	NewsFeed postNewsFeed(NewsFeed newsFeed) throws InvalidUserDetailsException, Exception;

}
