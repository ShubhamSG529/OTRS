package com.moments4u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Moments4UApplication {

	public static void main(String[] args) {
		SpringApplication.run(Moments4UApplication.class, args);
	}
}
