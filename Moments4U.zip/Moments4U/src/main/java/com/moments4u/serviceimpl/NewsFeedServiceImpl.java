package com.moments4u.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.entities.NewsFeed;
import com.moments4u.entities.User;
import com.moments4u.exception.ApplicationException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.repository.LikeDislikeRepository;
import com.moments4u.repository.NewsFeedRepository;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.NewsFeedService;

@Service
public class NewsFeedServiceImpl implements NewsFeedService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	NewsFeedRepository newsFeedRepository;

	@Autowired
	LikeDislikeRepository likeDislikeRepository;

	@Override
	public List<NewsFeedDto> getAllNewsFeeds(Integer userId) throws InvalidUserDetailsException {
		List<NewsFeedDto> newsFeedDtos = new ArrayList<NewsFeedDto>();
		if (userId != null) {
			User user = userRepository.findByUserId(userId);
			if (user != null) {
				List<NewsFeed> newsFeeds = newsFeedRepository.findByUser_UserIdOrderByDateTimeDesc(userId);
				if (newsFeeds.size() != 0) {
					for (NewsFeed newsFeed : newsFeeds) {
						NewsFeedDto newsFeedDto = new NewsFeedDto();
						newsFeedDto.setNewsFeedId(newsFeed.getNewsFeedId());
						newsFeedDto.setUserName(newsFeed.getUser().getUserName());
						newsFeedDto.setPost(newsFeed.getPost());
						newsFeedDto.setDateTime(new SimpleDateFormat("dd-MM-YYYY a").format(newsFeed.getDateTime()));

						Integer likeCount = likeDislikeRepository
								.findByNewsFeed_newsFeedIdAndLikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES")
								.size();
						Integer dislikeCount = likeDislikeRepository
								.findByNewsFeed_newsFeedIdAndDislikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES")
								.size();

						newsFeedDto.setDislikeCount(dislikeCount);
						newsFeedDto.setLikeCount(likeCount);

						newsFeedDtos.add(newsFeedDto);
					}
					return newsFeedDtos;
				} else {
					return null;
				}
			} else {
				throw new InvalidUserDetailsException("USER DOESN'T EXIST");
			}
		} else {
			throw new InvalidUserDetailsException("InvalidUserDetailsException SEARCHING BY USERID");
		}

	}

	@Override
	public NewsFeed postNewsFeed(NewsFeed newsFeed)
			throws InvalidUserDetailsException, ApplicationException, Exception {
		try {
			User user = userRepository.findByUserId(newsFeed.getUser().getUserId());
			if (user != null) {
				if (newsFeed.getPost() != null) {
					if (newsFeed.getPost().trim().equals("")) {
						throw new ApplicationException("NEWSFEED POST CANN'T BE EMPTY");
					}
					NewsFeed savedNewsFeed = newsFeedRepository.save(newsFeed);
					if (savedNewsFeed != null) {
						savedNewsFeed.setUser(user);
						return savedNewsFeed;
					} else {
						throw new ApplicationException("NEWSFEED POST DOESN'T SAVED SOMETHING WENT WRONG");
					}
				} else {
					throw new ApplicationException("NEWSFEED POST CANN'T BE NULL");
				}
			} else {
				throw new InvalidUserDetailsException("INVALID USER ID");
			}
		} catch (Exception e) {
			throw e;
		}
	}
}
