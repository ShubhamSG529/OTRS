package com.moments4u.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.moments4u.entities.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {

	ArrayList<Project> findByUser_UserId(Integer userId);

}
