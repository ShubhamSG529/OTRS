package com.moments4u.exception;

public class InvalidPasswordFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPasswordFormatException(String msg) {
		super(msg);
	}
}
