package com.moments4u.exception;

public class InvalidPhoneNumberException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidPhoneNumberException(String msg) {
		super(msg);
	}
}
