package com.moments4u.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.repository.LikeDislikeRepository;
import com.moments4u.repository.NewsFeedRepository;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.Test;

@Service
public class TestImpl implements Test{
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	NewsFeedRepository newsFeedRepository;

	@Autowired
	LikeDislikeRepository likeDislikeRepository;

	@Override
	public void test() {
		System.out.println("newsFeedRepository.findByNewsFeedId(10):  "+newsFeedRepository.findByNewsFeedId(10));
	}

}
