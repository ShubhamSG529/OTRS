package com.moments4u.serviceimpl;

import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.moments4u.entities.User;
import com.moments4u.exception.MySessionExpiredException;
import com.moments4u.service.SessionHandler;

@Service
public class SessionHandlerImpl implements SessionHandler {
	public static final String USER_SESSION_OBJECT = "user_object";
	public static final String LAST_ACCESSED_TIME = "last_accessed_time";

	public static final Integer SESSION_EXPIRATION_TIME = 30;

	@Override
	public void handleSession(HttpServletRequest request) throws MySessionExpiredException {
		//boolean flag = true;

		HttpSession session = request.getSession(false);
		System.out.println("session : " + session);
		if (session == null) {
			//return false;
			throw new MySessionExpiredException("/users Your Session is Expired");
		}
		User loggedInUser = (User) session.getAttribute(USER_SESSION_OBJECT);
		System.out.println("handleSession loggedInUser :  " + loggedInUser);
		if (loggedInUser == null) {
			//flag = false;
			throw new MySessionExpiredException("/users Your Session is Expired");
		} else {
			long lastAccessedTimeInMinuts = TimeUnit.MILLISECONDS
					.toMinutes(System.currentTimeMillis() - (Long) session.getAttribute(LAST_ACCESSED_TIME));
			System.out.println("minuts : " + lastAccessedTimeInMinuts);
			System.out.println(lastAccessedTimeInMinuts);
			if (lastAccessedTimeInMinuts > SESSION_EXPIRATION_TIME) {
				System.out.println("SESSION INVALIDATE");
				session.invalidate();
				//flag = false;
				throw new MySessionExpiredException("/users Your Session is Expired");
			} else {
				session.setAttribute(LAST_ACCESSED_TIME, System.currentTimeMillis());
			}
		}
	}
}
