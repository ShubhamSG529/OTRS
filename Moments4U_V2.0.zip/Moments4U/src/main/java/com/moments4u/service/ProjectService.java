package com.moments4u.service;

import java.util.List;

import com.moments4u.dto.ProjectDto;

public interface ProjectService {

	List<ProjectDto> getAllProjects();

}
