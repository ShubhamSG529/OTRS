handleCookie();
var loggedInUserId;
function postNewsFeed() {
	var comment = document.getElementById("comment").value;

	if (comment != "" && comment != null) {
		var newsFeedObject = createNewsFeedObject(comment);
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = postedNewsfeed;
		xhttp.open("POST", "http://localhost:7070/post_newsfeed", false);
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(newsFeedObject);
	}
}
function postedNewsfeed() {
	if (this.readyState == 4 && (this.status == 202 || this.status == 200)) {
		var parsedResponse = JSON.parse(this.responseText);
		// alert(this.responseText);

		var showNewsFeedDiv = document.getElementById("show_news_feed_div");
		showNewsFeedDiv.innerHTML = "";
		// $("#news_feed_div").load("NewsFeed.jsp");
		newsFeedInitAll2(0); // (0) All news feeds
		document.getElementById("comment").value = "";
		// window.location.reload();

	} else if (this.readyState == 4 && this.status == 500) {
		var parsedResponse = JSON.parse(this.responseText);
		alert(this.responseText);
	}
}
function createNewsFeedObject(comment) {
	return "{\"user\":{\"userId\":\"" + loggedInUserId + "\"}," + "\"post\":\""
			+ comment + "\"}";
}
function handleCookie() {
	var flag = 'true';
	var cookies = document.cookie;
	var objectArray = cookies.split(";");

	for (var i = 0; i < objectArray.length; i++) {
		var userArray = objectArray[i].split("=");
		if (userArray[0] == "user_object") {
			if (userArray[1] == "") {
				flag = 'false';
			} else {
				var parsedUserResponse = JSON.parse(userArray[1]);
				loggedInUserId = parsedUserResponse.userId;
			}
		}
	}
	if (flag == 'false') {
		window.location = "HomePage.jsp";
	}
}