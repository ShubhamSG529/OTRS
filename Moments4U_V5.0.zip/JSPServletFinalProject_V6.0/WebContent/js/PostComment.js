function postNewsFeed() {
	var comment = document.getElementById("comment").value;

	if (comment != "" && comment != null) {
		var newsFeedObject = createNewsFeedObject(comment);
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = postedNewsfeed;
		xhttp.open("POST", "http://localhost:7070/post_newsfeed", false);
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(newsFeedObject);
	}
}
function postedNewsfeed() {
	if (this.readyState == 4 && (this.status == 202 || this.status == 200)) {
		var parsedResponse = JSON.parse(this.responseText);

		var showNewsFeedDiv = document.getElementById("show_news_feed_div");
		showNewsFeedDiv.innerHTML = "";
		
		newsFeedCount = 0;
		newsFeedDataIsExist = true;
		
		newsFeedInitAll2();
		document.getElementById("comment").value = "";

	} else if (this.readyState == 4 && this.status == 500) {
		var parsedResponse = JSON.parse(this.responseText);
		alert(this.responseText);
	}
}
function createNewsFeedObject(comment) {
	return "{\"user\":{\"userId\":\"" + loggedInUserId + "\"}," + "\"post\":\""
			+ comment + "\"}";
}