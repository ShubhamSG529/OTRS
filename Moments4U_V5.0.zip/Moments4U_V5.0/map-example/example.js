google.maps.event.addDomListener(window, 'load', initAll);

var map;
var marker;var marker2;
var myLatlng = new google.maps.LatLng(20.265315667699287,85.83337488159782);
var geocoder = new google.maps.Geocoder();
var infowindow = new google.maps.InfoWindow();

var x;
function initAll(){
	document.getElementById("user_address_input").onfocus = setSearchAddress;
	
	initialize(); 

	//on map load get all details and fill inputs value
	setDefaultLatLng();

	//set new input values based on marker dragged
	setNewLatLng(map,marker);
	
	//add new marker position on address search
	var geocoderr = new google.maps.Geocoder();
	document.getElementById('submit').addEventListener('click', function() {
		addSearchMarker(geocoderr, map);
	});

	x = document.getElementById("demo");
	getLocation();
}

function getLocation() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(showPosition);
	} else { 
		x.innerHTML = "Geolocation is not supported by this browser.";
	}
}
function showPosition(position) {
	x.innerHTML = "Latitude: " + position.coords.latitude + 
	"<br>Longitude: " + position.coords.longitude;

	myLatlng = new google.maps.LatLng(position.coords.latitude,
							position.coords.longitude);
	map.setCenter(myLatlng);
	marker.setPosition(myLatlng);

	addressFromLatLng(geocoder, map, infowindow,myLatlng);
}


function addSearchMarker(geocoder, resultsMap) {
	var address = document.getElementById('user_address_input').value;

	geocoder.geocode({'address': address}, function(results, status) {
		if (status === 'OK') {
			
			//alert("searched loc "+results[0].geometry.location);
			//alert(results[0].geometry.location.lat());
			//alert(results[0].geometry.location.lng());
			myLatlng = new google.maps.LatLng(results[0].geometry.location.lat(),
							results[0].geometry.location.lng());
			//alert("new searched "+myLatlng);

			resultsMap.setCenter(results[0].geometry.location);
			marker.setPosition(results[0].geometry.location);
			
			fillInputs(results[0],marker);

		} else {
			alert('Geocode was not successful for the following reason: ' + status);
		}
	});

	google.maps.event.addListener(marker2, 'dragend', function() {
		geocoder.geocode({'latLng': marker2.getPosition()}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
				if (results[0]) {
					$('#address').val(results[0].formatted_address);
					$('#latitude').val(marker2.getPosition().lat());
					$('#longitude').val(marker2.getPosition().lng());
					infowindow.setContent(results[0].formatted_address);
					infowindow.open(map, marker2);
				}
			}
		});
	});
}

function fillInputs(rs,mkr){
	$('#address').val(rs.formatted_address);
	$('#latitude').val(mkr.getPosition().lat());
	$('#longitude').val(mkr.getPosition().lng());
	infowindow.setContent(rs.formatted_address);
	infowindow.open(map, mkr);
}

function initialize(){
	//alert("initialize start "+myLatlng);
	var mapOptions = {
		zoom: 18,
		center: myLatlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};

	map = new google.maps.Map(document.getElementById("myMap"), mapOptions);

	marker = new google.maps.Marker({
		map: map,
		position: myLatlng,
		draggable: true 
	});
	//alert("initialize end "+myLatlng);
}

function setDefaultLatLng(){
	geocoder.geocode({'latLng': myLatlng }, function(results, status) {
		if (status == google.maps.GeocoderStatus.OK) {
			if (results[0]) {
				$('#latitude,#longitude').show();
				$('#address').val(results[0].formatted_address);
				$('#latitude').val(marker.getPosition().lat());
				$('#longitude').val(marker.getPosition().lng());
				infowindow.setContent(results[0].formatted_address);
				infowindow.open(map, marker);
			}
		}
	});
	//alert("default "+myLatlng);
}

function setNewLatLng(map,marker){
	//alert("new latLng");
	google.maps.event.addListener(marker, 'dragend', function() {
		geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
				if (results[0]) {

					myLatlng = new google.maps.LatLng(marker.getPosition().lat(),
							marker.getPosition().lng());

					$('#address').val(results[0].formatted_address);
					$('#latitude').val(marker.getPosition().lat());
					$('#longitude').val(marker.getPosition().lng());
					infowindow.setContent(results[0].formatted_address);
					infowindow.open(map, marker);

					//alert("new dragged "+myLatlng);
				}
			}
		});
	});
}

function setSearchAddress(){
	var sb = document.getElementById("user_address_input");
	//var searchBox = new google.maps.places.SearchBox(document.getElementById("area"));
	var searchBox = new google.maps.places.SearchBox(sb);

	//place change event on search box
	google.maps.event.addListener(searchBox,"place_changed",function(){
		
		//console.log(searchBox.getPlaces());
		var places = searchBox.getPlaces();

		//bound
		var bounds = new google.maps.LatLngBounds();
		var i,place;

		for(i=0;place=places[i];i++){
			//console.log(place.geometry.location);

			bounds.extend(place.geometry.location);
			marker.setPosition(place.geometry.location); //set marker position new
		}

		map.fitBounds(bounds);  //fit to the bound
		map.setZoom(15);  //set zoom
		
	});	
}

function addressFromLatLng(geocoder, map, infowindow,latlng) {
	geocoder.geocode({'location': latlng}, function(results, status) {
		if (status === 'OK') {
			if (results[0]) {
				map.setZoom(18);
				marker.setPosition(latlng);

				infowindow.setContent(results[0].formatted_address);
				infowindow.open(map, marker);

				$('#address').val(results[0].formatted_address);
				$('#latitude').val(marker.getPosition().lat());
				$('#longitude').val(marker.getPosition().lng());

			} else {
				window.alert('No results found');
			}
		} else {
			window.alert('Geocoder failed due to: ' + status);
		}
	});
}