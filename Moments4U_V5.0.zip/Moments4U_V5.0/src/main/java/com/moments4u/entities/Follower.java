package com.moments4u.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Follower {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer followerId;

	@ManyToOne
	private User followingUser;

	@ManyToOne
	private User fUser;

	public Integer getFollowerId() {
		return followerId;
	}

	public void setFollowerId(Integer followerId) {
		this.followerId = followerId;
	}

	public User getFollowingUser() {
		return followingUser;
	}

	public void setFollowingUser(User followingUser) {
		this.followingUser = followingUser;
	}

	public User getfUser() {
		return fUser;
	}

	public void setfUser(User fUser) {
		this.fUser = fUser;
	}

	@Override
	public String toString() {
		return "Follower [followerId=" + followerId + ", followingUser=" + followingUser + ", fUser=" + fUser + "]";
	}

}
