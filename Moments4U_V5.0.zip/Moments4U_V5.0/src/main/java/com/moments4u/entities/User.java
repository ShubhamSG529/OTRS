package com.moments4u.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private Integer userId;

	@Column(nullable = false)
	private String userName;

	@Column(nullable = false)
	private String category;

	@Column(nullable = false)
	private String profession;

	@Column(nullable = true)
	private String rank;

	@Column(nullable = true)
	private String certificate;

	@Column(nullable = false, length = 6)
	private String gender;

	@Column(nullable = false, unique = true)
	private String email;

	@Column(nullable = false, unique = true, length = 10)
	private String phoneNumber;

	@Column(nullable = true)
	private String address;

	@Column(nullable = false/* , length = 80 */)
	// @JsonIgnore
	private String password;

	@Column(nullable = true)
	private String profilePicturePath;

	@Column(nullable = false)
	private String onlineStatus = "OFFLINE";

	@Column(nullable = true)
	private Integer age;

	@Column(nullable = true)
	private String achivement;

	@Column(nullable = true)
	private String description;

	@Column(nullable = true)
	private Integer active = 1;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfilePicturePath() {
		return profilePicturePath;
	}

	public void setProfilePicturePath(String profilePicturePath) {
		this.profilePicturePath = profilePicturePath;
	}

	public String getOnlineStatus() {
		return onlineStatus;
	}

	public void setOnlineStatus(String onlineStatus) {
		this.onlineStatus = onlineStatus;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getAchivement() {
		return achivement;
	}

	public void setAchivement(String achivement) {
		this.achivement = achivement;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getActive() {
		return active;
	}

	public void setActive(Integer active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", category=" + category + ", profession="
				+ profession + ", rank=" + rank + ", certificate=" + certificate + ", gender=" + gender + ", email="
				+ email + ", phoneNumber=" + phoneNumber + ", address=" + address + ", password=" + password
				+ ", profilePicturePath=" + profilePicturePath + ", onlineStatus=" + onlineStatus + ", age=" + age
				+ ", achivement=" + achivement + ", description=" + description + ", active=" + active + "]";
	}

}
