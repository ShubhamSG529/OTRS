package com.moments4u.dto;

import java.util.ArrayList;

import com.moments4u.entities.Project;
import com.moments4u.entities.User;

public class UserDto {
	private Integer userId;
	private String userName;
	private String category;
	private String profession;
	private String rank;
	private String certificate;
	private String gender;
	private String email;
	private String phoneNumber;
	private String address;
	private String profilePicturePath;
	private String onlineStatus = "OFFLINE";
	private Integer age;
	private String achivement;
	private String description;
	private ArrayList<User> following;
	private ArrayList<User> followers;

	private ArrayList<Project> projects;

	public void setUserObject(User user) {
		this.userId = user.getUserId();
		this.userName = user.getUserName();
		this.category = user.getCategory();
		this.profession = user.getProfession();
		this.rank = user.getRank();
		this.certificate = user.getCertificate();
		this.gender = user.getGender();
		this.email = user.getEmail();
		this.phoneNumber = user.getPhoneNumber();
		this.address = user.getAddress();
		this.profilePicturePath = user.getProfilePicturePath();
		this.onlineStatus = user.getOnlineStatus();
		this.age = user.getAge();
		this.achivement = user.getAchivement();
		this.description = user.getDescription();
	}

	public Integer getUserId() {
		return userId;
	}

	public String getUserName() {
		return userName;
	}

	public String getCategory() {
		return category;
	}

	public String getProfession() {
		return profession;
	}

	public String getRank() {
		return rank;
	}

	public String getCertificate() {
		return certificate;
	}

	public String getGender() {
		return gender;
	}

	public String getEmail() {
		return email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public String getProfilePicturePath() {
		return profilePicturePath;
	}

	public String getOnlineStatus() {
		return onlineStatus;
	}

	public Integer getAge() {
		return age;
	}

	public String getAchivement() {
		return achivement;
	}

	public String getDescription() {
		return description;
	}

	public ArrayList<User> getFollowing() {
		return following;
	}

	public void setFollowing(ArrayList<User> following) {
		this.following = following;
	}

	public ArrayList<User> getFollowers() {
		return followers;
	}

	public void setFollowers(ArrayList<User> followers) {
		this.followers = followers;
	}

	public ArrayList<Project> getProjects() {
		return projects;
	}

	public void setProjects(ArrayList<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", userName=" + userName + ", category=" + category + ", profession="
				+ profession + ", rank=" + rank + ", certificate=" + certificate + ", gender=" + gender + ", email="
				+ email + ", phoneNumber=" + phoneNumber + ", address=" + address + ", profilePicturePath="
				+ profilePicturePath + ", onlineStatus=" + onlineStatus + ", age=" + age + ", achivement=" + achivement
				+ ", description=" + description + ", following=" + following + ", followers=" + followers + "]";
	}

}
