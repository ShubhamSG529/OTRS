package com.moments4u.service;

import com.moments4u.entities.Feedback;

public interface FeedbackService {
	public Feedback saveFeedback(Feedback feedback);
}
