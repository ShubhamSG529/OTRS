package com.moments4u.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface UploadFileService {

	String upload(MultipartFile file,int loggedInuserId) throws FileNotFoundException, IOException;

}
