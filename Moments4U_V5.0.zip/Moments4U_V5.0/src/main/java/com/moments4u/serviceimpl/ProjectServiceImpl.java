package com.moments4u.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.dto.ProjectDto;
import com.moments4u.entities.Project;
import com.moments4u.repository.ProjectRepository;
import com.moments4u.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectRepository projectRepository;

	@Override
	public List<ProjectDto> getAllProjects() {
		List<Project> projectList = projectRepository.findAll();
		if (projectList.size() != 0) {
			List<ProjectDto> projectDtoList = new ArrayList<ProjectDto>();
			for (Project project : projectList) {
				ProjectDto projectDto = new ProjectDto();
				projectDto.setProjectId(project.getProjectId());
				projectDto.setDateTime(new SimpleDateFormat("dd-MM-YYYY").format(project.getDateTime()));
				
				String[] splitedFileName = project.getFilePath().split("/");
				projectDto.setFileName(splitedFileName[splitedFileName.length-1]);
				
				projectDto.setFormat(project.getFormat());
				projectDto.setStatus(project.getStatus());
				projectDto.setUserName(project.getUser().getUserName());

				projectDtoList.add(projectDto);
			}

			return projectDtoList;
		} else {
			return null;
		}
	}

}
