package com.moments4u.exception;

public class DuplicatePhoneNumberException extends Exception {
	private static final long serialVersionUID = 1L;

	public DuplicatePhoneNumberException(String msg) {
		super(msg);
	}
}
