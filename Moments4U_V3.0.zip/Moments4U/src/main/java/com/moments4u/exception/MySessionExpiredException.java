package com.moments4u.exception;

public class MySessionExpiredException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MySessionExpiredException(String msg) {
		super(msg);
	}

}
