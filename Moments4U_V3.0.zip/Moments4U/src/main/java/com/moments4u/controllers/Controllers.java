package com.moments4u.controllers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.dto.ProjectDto;
import com.moments4u.dto.UserDto;
import com.moments4u.entities.ErrorDetails;
import com.moments4u.entities.NewsFeed;
import com.moments4u.entities.User;
import com.moments4u.exception.DuplicateEmailException;
import com.moments4u.exception.DuplicatePhoneNumberException;
import com.moments4u.exception.InvalidEmailFormatException;
import com.moments4u.exception.InvalidGenderTypeException;
import com.moments4u.exception.InvalidOnlineStatusTypeException;
import com.moments4u.exception.InvalidPasswordFormatException;
import com.moments4u.exception.InvalidPhoneNumberException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.InvalidUserNameException;
import com.moments4u.exception.MySessionExpiredException;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.SessionHandler;
import com.moments4u.service.NewsFeedService;
import com.moments4u.service.ProjectService;
import com.moments4u.service.Test;
import com.moments4u.service.UploadFileService;
import com.moments4u.service.UserService;
import com.moments4u.serviceimpl.SessionHandlerImpl;

@RestController
@CrossOrigin
@SessionAttributes(SessionHandlerImpl.USER_SESSION_OBJECT)
public class Controllers implements ErrorController {
	@Autowired
	UserService userService;

	@Autowired
	NewsFeedService newsFeedService;

	@Autowired
	ProjectService projectService;

	@Autowired
	UploadFileService uploadFileService;

	@Autowired
	SessionHandler sessionHandler;

	@Autowired
	Test testService;

	@Autowired
	UserRepository userRepository;

	// For testing purpose only
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showLoginPage(ModelMap model) {
		System.out.println("INDEX.JSP");
		// return "index";

		return new ModelAndView("index.jsp");
	}

	@RequestMapping("/error")
	public String handleError(HttpServletRequest request, HttpServletResponse response) {

		final Integer STATUS_CODE = response.getStatus();
		final Date CURRENT_TIME = new Date();
		System.out.println("ERROR PAGE :" + STATUS_CODE);
		String htmlError = "<!DOCTYPE html><html><style>body,html {height: 100%;margin: 0;}.bgimg {background-image: url('error.jpg');height: 100%;"
				+ "background-position: center;background-size: cover;position: relative;color: white;font-family: 'Courier New', Courier, monospace;"
				+ "font-size: 25px;}.topleft {position: absolute;top: 0;left: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".topright {position: absolute;right: 0;margin-right: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".bottomleft {position: absolute;bottom: 0;left: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".bottomright {position: absolute;bottom: 0;right: 0;margin-right: 16px;font-weight: bold;font-family: 'Times New Roman', Times, serif;}"
				+ ".middle {position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;}"
				+ "hr {margin: auto;width: 60%;}</style><body><div class='bgimg'><div class='topleft'><p>ERROR PAGE</p></div><div class='topright'><p>STATUS : "
				+ STATUS_CODE
				+ "</p></div><div class='middle'><h1>SOMETHING WENT WRONG !!!</h1><h1>WE ARE WORKING ON IT</h1></div><div class='bottomleft'><p>"
				+ CURRENT_TIME + "</p>"
				+ "</div><div class='bottomright'><p>INTERNAL SERVER ERROR</p></div></div></body></html>";

		return htmlError;
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
		System.out.println("!! handleAllExceptions !!");
		// ex.printStackTrace();

		ErrorDetails errorDetails = new ErrorDetails();
		errorDetails.setMessage(ex.getMessage());
		errorDetails.setException(ex.getClass().toString());
		errorDetails.setStatus("500");

		return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> signup(@RequestBody User user, HttpServletRequest request)
			throws DuplicateEmailException, DuplicatePhoneNumberException, InvalidPhoneNumberException,
			InvalidGenderTypeException, InvalidOnlineStatusTypeException, InvalidUserNameException,
			InvalidEmailFormatException, InvalidPasswordFormatException {

		User signedUpUser = userService.signupUser(user);
		if (signedUpUser != null) {
			HttpSession session = request.getSession(true);
			session.setAttribute(SessionHandlerImpl.USER_SESSION_OBJECT, signedUpUser);
			session.setAttribute(SessionHandlerImpl.LAST_ACCESSED_TIME, System.currentTimeMillis());

			return new ResponseEntity<User>(signedUpUser, HttpStatus.ACCEPTED);// #202
		} else
			return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);// #406
	}

	@RequestMapping(value = "/signin", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> signin(@RequestBody User user, HttpServletRequest request)
			throws InvalidUserDetailsException {

		User signedInUser = userService.signinUser(user);
		if (signedInUser != null) {
			HttpSession session = request.getSession(true);
			session.setAttribute(SessionHandlerImpl.USER_SESSION_OBJECT, signedInUser);
			session.setAttribute(SessionHandlerImpl.LAST_ACCESSED_TIME, System.currentTimeMillis());

			System.out.println(
					"/signin Session Variable " + session.getAttribute(SessionHandlerImpl.USER_SESSION_OBJECT));

			return new ResponseEntity<User>(signedInUser, HttpStatus.ACCEPTED);
		} else
			return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserDto> getUser(@RequestBody User user, HttpServletRequest request)
			throws InvalidUserDetailsException, MySessionExpiredException {

		// sessionHandler.handleSession(request);

		UserDto getUserDtoById = userService.getUser(user);
		if (getUserDtoById != null)
			return new ResponseEntity<UserDto>(getUserDtoById, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<UserDto>(HttpStatus.NOT_ACCEPTABLE);
	}

	@RequestMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getAllUser(HttpServletRequest request) throws MySessionExpiredException {

		//sessionHandler.handleSession(request);

		List<User> users = userService.getAllUser();
		if (users != null) {
			return new ResponseEntity<List<User>>(users, HttpStatus.ACCEPTED);
		} else
			return new ResponseEntity<List<User>>(HttpStatus.NOT_ACCEPTABLE);
	}

	@RequestMapping(value = "/all_news_feed", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<NewsFeedDto>> allNewsFeedByUserId(@RequestBody User user, HttpServletRequest request)
			throws InvalidUserDetailsException, MySessionExpiredException {

		// System.out.println("/all_news_feed ------------");
		// sessionHandler.handleSession(request);

		List<NewsFeedDto> newsFeeds = newsFeedService.getAllNewsFeeds(user.getUserId());
		if (newsFeeds != null) {
			return new ResponseEntity<List<NewsFeedDto>>(newsFeeds, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<List<NewsFeedDto>>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@RequestMapping(value = "/action_newsfeed", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NewsFeedDto> actionOnNewsFeed(@RequestBody NewsFeed newsFeed,
			@RequestParam("action") String action, HttpServletRequest request) throws MySessionExpiredException {

		// sessionHandler.handleSession(request);

		NewsFeedDto newsFeedDto = newsFeedService.actionOnNewsFeeds(newsFeed, action);
		if (newsFeedDto != null) {
			return new ResponseEntity<NewsFeedDto>(newsFeedDto, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<NewsFeedDto>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@RequestMapping(value = "/projects", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProjectDto>> allProjects(HttpServletRequest request) throws MySessionExpiredException {

		// sessionHandler.handleSession(request);

		List<ProjectDto> projects = projectService.getAllProjects();
		if (projects != null) {
			return new ResponseEntity<List<ProjectDto>>(projects, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<List<ProjectDto>>(HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@RequestMapping(value = "/post_newsfeed", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NewsFeed> addNewsFeeds(@RequestBody NewsFeed newsFeed, HttpServletRequest request)
			throws Exception {

		// sessionHandler.handleSession(request);

		NewsFeed addedNewsFeed = newsFeedService.postNewsFeed(newsFeed);

		return new ResponseEntity<NewsFeed>(addedNewsFeed, HttpStatus.ACCEPTED);// #202
	}

	@RequestMapping(value = "/update_profile", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> updateUserProfile(@RequestBody User user, HttpServletRequest request)
			throws InvalidUserDetailsException, MySessionExpiredException {

		// sessionHandler.handleSession(request);

		User updatedUser = userService.updateUserProfile(user);
		if (updatedUser != null) {
			return new ResponseEntity<User>(updatedUser, HttpStatus.ACCEPTED);// #202
		} else {
			return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);// #406
		}
	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = "multipart/form-data", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> uploadVideoImages(@RequestParam("img") MultipartFile file)
			throws FileNotFoundException, IOException {

		System.out.println("file : " + file);
		String result = uploadFileService.upload(file);

		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}

	// For testing purpose only
	@RequestMapping(value = "/session")
	public String createSession(HttpServletRequest request) throws InvalidUserDetailsException {
		HttpSession session = request.getSession();
		User user = new User();
		user.setUserId(10);
		User getUserById = userRepository.findByUserId(user.getUserId());

		session.setAttribute(SessionHandlerImpl.USER_SESSION_OBJECT, getUserById);
		session.setAttribute(SessionHandlerImpl.LAST_ACCESSED_TIME, System.currentTimeMillis());
		return "Session Created";
	}

	@RequestMapping(value = "/logout")
	public void logout(HttpServletRequest request) {
		System.out.println("LogOut");
		HttpSession session = request.getSession();
		session.invalidate();
	}

	// For testing purpose only
	@RequestMapping(value = "/test")
	public String testMethod() {
		testService.test();

		return "Test String";
	}
}
