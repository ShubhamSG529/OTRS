package com.moments4u.service;

public interface Test {

	void test();
	
}
