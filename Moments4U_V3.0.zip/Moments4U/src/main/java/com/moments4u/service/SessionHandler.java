package com.moments4u.service;

import javax.servlet.http.HttpServletRequest;

import com.moments4u.exception.MySessionExpiredException;

public interface SessionHandler {
	public void handleSession(HttpServletRequest request) throws MySessionExpiredException;
}
