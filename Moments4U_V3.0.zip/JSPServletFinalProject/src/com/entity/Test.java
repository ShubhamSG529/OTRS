package com.entity;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class Test {
	/*public static void main(String[] args) {
		ScriptEngineManager manager = new ScriptEngineManager();
	    ScriptEngine engine = manager.getEngineByName("javascript");

	    try {
	    	Object eval = engine.eval("<script>document.writeln('{\"userId\":\"10\"}')</script>");
			System.out.println("eval : " + eval);
		} catch (Exception e) {
			System.out.println("ScriptException : " + e.getMessage());
		}	    
	}*/

	public static User convert(String jsonString) {
		System.out.println("jsonString :: " + jsonString);
		// JsonParser parser = new JsonParser();
		// JsonObject jsonObject = (JsonObject)parser.parse(str);
		User user = null;
		try {
			Gson gson = new Gson();
			user = gson.fromJson(jsonString, User.class);
		} catch (JsonSyntaxException e) {
			// System.out.println("JsonSyntaxException " + e.getMessage());
		}
		return user;
	}
	public static void convert(Object object) {
		System.out.println("Object : " + object);		
	}
	public static void convert(int value) {
		System.out.println("int value : " + value);
		String str = String.valueOf(value);
		System.out.println("Converted from hash Code : "+str);
	}
}
