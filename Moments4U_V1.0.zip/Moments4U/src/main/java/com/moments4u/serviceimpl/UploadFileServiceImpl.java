package com.moments4u.serviceimpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.moments4u.service.UploadFileService;

@Service
public class UploadFileServiceImpl implements UploadFileService {

	@Override
	public String upload(MultipartFile file) throws FileNotFoundException, IOException {
		String fileName = file.getOriginalFilename().toString().trim();
		String fileExtension = fileName.split("\\.")[1];
		long fileSizeInKB = file.getSize() / 1000;
		String newFileName = System.currentTimeMillis() + "_" + (int) (Math.random() * 1000000000) + "."
				+ fileExtension;

		System.out.println("ORIGINAL FILENAME : " + fileName);
		System.out.println("CONTENT TYPE : " + file.getContentType());// image/jpeg
		System.out.println("FILE EXTENSION:" + fileExtension);
		System.out.println("FILE SIZE:" + fileSizeInKB + " KB");

		try {
			InputStream inputStream = file.getInputStream();

			int fileSizeToBeWriteOnce;
			OutputStream outputStream = new FileOutputStream(new File("uploads/" + newFileName));
			byte[] buffer = new byte[8192];
			while ((fileSizeToBeWriteOnce = inputStream.read(buffer, 0, buffer.length)) != -1) {
				outputStream.write(buffer, 0, fileSizeToBeWriteOnce);
			}
			outputStream.close();
			System.out.println("YOU SUCCESSFULLY UPLOADED INTO //uploads/" + newFileName);

			return "YOU SUCCESSFULLY UPLOADED INTO //uploads/" + newFileName;
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		}
	}

}
