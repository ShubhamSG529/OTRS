package com.moments4u.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.moments4u.entities.LikeDislike;

@Repository
public interface LikeDislikeRepository extends JpaRepository<LikeDislike, Integer> {

	List<LikeDislike> findByNewsFeed_newsFeedIdAndLikeStatusIgnoreCase(Integer newsFeedId, String likeStatus);

	List<LikeDislike> findByNewsFeed_newsFeedIdAndDislikeStatusIgnoreCase(Integer newsFeedId, String string);

	List<LikeDislike> findByNewsFeed_newsFeedIdAndUser_userIdAndLikeStatusAndDislikeStatus(Integer newsFeedId,
			Integer userId, String likeStatus, String dislikeStatus);

	List<LikeDislike> findByNewsFeed_newsFeedIdAndUser_userId(Integer newsFeedId, Integer userId);

	void deleteByNewsFeed_newsFeedIdAndUser_userId(Integer newsFeedId, Integer userId);

}
