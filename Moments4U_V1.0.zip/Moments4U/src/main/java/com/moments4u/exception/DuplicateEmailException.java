package com.moments4u.exception;

public class DuplicateEmailException extends Exception {
	private static final long serialVersionUID = 1L;

	public DuplicateEmailException(String msg) {
		super(msg);
	}
}
