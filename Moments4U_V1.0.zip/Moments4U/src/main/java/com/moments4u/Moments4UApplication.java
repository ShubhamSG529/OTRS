package com.moments4u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableAutoConfiguration
public class Moments4UApplication {

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(Moments4UApplication.class);

		app.run(args);
	}

	/*@Bean
	WebMvcConfigurer configurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addResourceHandlers(ResourceHandlerRegistry registry) {
				registry.addResourceHandler("/images/**").addResourceLocations("classpath:/webapp/images/");
			}
		};
	}*/

}
