package com.moments4u.dto;

public class NewsFeedDto {
	private Integer newsFeedId;
	private String userName;
	private String post;
	private String dateTime;
	private String timeAgo;
	private Integer likeCount;
	private Integer dislikeCount;

	public Integer getNewsFeedId() {
		return newsFeedId;
	}

	public void setNewsFeedId(Integer newsFeedId) {
		this.newsFeedId = newsFeedId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getTimeAgo() {
		return timeAgo;
	}

	public void setTimeAgo(String timeAgo) {
		this.timeAgo = timeAgo;
	}

	public Integer getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Integer likeCount) {
		this.likeCount = likeCount;
	}

	public Integer getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(Integer dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	@Override
	public String toString() {
		return "NewsFeedDto [newsFeedId=" + newsFeedId + ", userName=" + userName + ", post=" + post + ", dateTime="
				+ dateTime + ", timeAgo=" + timeAgo + ", likeCount=" + likeCount + ", dislikeCount=" + dislikeCount
				+ "]";
	}

}
