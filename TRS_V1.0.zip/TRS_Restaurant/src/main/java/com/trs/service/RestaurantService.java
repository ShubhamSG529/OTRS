package com.trs.service;

import java.util.List;

import com.trs.dto.RestaurantBillDto;
import com.trs.entity.Restaurant;

public interface RestaurantService {
	List<Restaurant> getAllRestaurants();

	Restaurant getRestaurant(int restaurantId);

	RestaurantBillDto generateOrderBill(int userId,String accessToken);
}
