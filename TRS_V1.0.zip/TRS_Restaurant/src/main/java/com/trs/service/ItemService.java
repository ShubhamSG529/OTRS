package com.trs.service;

import java.util.List;

import com.trs.entity.Item;

public interface ItemService {
	List<Item> getItemsByRestaurantId(int restaurantId);
}
