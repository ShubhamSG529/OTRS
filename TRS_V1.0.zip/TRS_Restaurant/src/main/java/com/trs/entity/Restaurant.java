package com.trs.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restId;

	@Column(unique = true)
	private String restName;
	private String restAddress;
	@Column(unique = true)
	private String restContact;
	private String imagePath;

	@ManyToMany
	@JsonIgnore
	List<Item> items = new ArrayList<Item>();

	public Restaurant() {

	}

	public Restaurant(int restId) {
		this.restId = restId;
	}

	public Restaurant(String restName, String restAddress, String restContact, String imagePath) {
		super();
		this.restName = restName;
		this.restAddress = restAddress;
		this.restContact = restContact;
		this.imagePath = imagePath;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}

	public String getRestContact() {
		return restContact;
	}

	public void setRestContact(String restContact) {
		this.restContact = restContact;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public int getRestId() {
		return restId;
	}

	public void setRestId(int restId) {
		this.restId = restId;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "Restaurant [rest_id=" + restId + ", restName=" + restName + ", restAddress=" + restAddress
				+ ", restContact=" + restContact + ", imagePath=" + imagePath + "]";
	}
}
