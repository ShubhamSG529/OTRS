package com.trs.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trs.entity.Item;
import com.trs.repo.ItemRepo;
import com.trs.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemRepo itemRepository;

	@Override
	public List<Item> getItemsByRestaurantId(int restaurantId) {
		List<Item> items = itemRepository.findByRestaurants_RestId(restaurantId);
		System.out.println("items:   " + items);

		if (items != null) {
			return items;
		} else {
			return null;
		}
	}

}
