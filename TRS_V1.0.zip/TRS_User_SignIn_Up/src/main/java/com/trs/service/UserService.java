package com.trs.service;

import java.util.List;

import com.trs.entity.User;

public interface UserService {

	User signupUser(User user);

	List<User> getAllUsers();

	User getUser(User user);

	User getUserById(User user);

	User getUserById(int userId);

}
