package com.trs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrsRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrsRegisterApplication.class, args);
	}
}
