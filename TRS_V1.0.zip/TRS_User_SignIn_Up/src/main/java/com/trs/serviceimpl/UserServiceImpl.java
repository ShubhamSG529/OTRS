package com.trs.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trs.entity.User;
import com.trs.repo.UserRepo;
import com.trs.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;

	@Override
	public User signupUser(User user) {
		User signedUpUser = null;
		try {
			signedUpUser = userRepo.save(user);
		} catch (Exception e) {
			System.out.println("SignupUser catch: "+e.getMessage());
		}
		return signedUpUser;
	}

	@Override
	public User getUser(User user) {
		return userRepo.findByEmail(user.getEmail());
	}

	@Override
	public List<User> getAllUsers() {
		List<User> allUsers = userRepo.findAll();
		if (allUsers.size() != 0)
			return allUsers;
		else
			return null;
	}

	@Override
	public User getUserById(User user) {
		User getUser = userRepo.findByUserId(user.getUserId());
		System.out.println("getUserById: " + getUser);
		if (getUser != null) {
			return getUser;
		}
		return null;
	}

	@Override
	public User getUserById(int userId) {
		User user = userRepo.findByUserId(userId);
		if (user != null) {
			return user;
		} else {
			return null;
		}
	}

}
