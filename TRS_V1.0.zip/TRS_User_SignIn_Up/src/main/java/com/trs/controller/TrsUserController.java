package com.trs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trs.entity.User;
import com.trs.service.UserService;

@RestController
@CrossOrigin
public class TrsUserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> signupUser(@RequestBody User user) {
		System.out.println("/signup "+user);
		User addedUser = userService.signupUser(user);
		if (addedUser != null)
			return new ResponseEntity<User>(addedUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.CONFLICT);
	}

	@RequestMapping(value = "/signin", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> signinUser(@RequestBody User user) {
		System.out.println("/signin "+user);
		User getUser = userService.getUser(user);
		if (getUser != null)
			return new ResponseEntity<User>(getUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> allUsers() {
		System.out.println("/users");
		List<User> allUser = userService.getAllUsers();
		if (allUser != null)
			return new ResponseEntity<List<User>>(allUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/user/{user_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> getUser(@PathVariable("user_id") int userId) {
		System.out.println("/user/{user_id}");
		User getUser = userService.getUserById(userId);
		if (getUser != null)
			return new ResponseEntity<User>(getUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/public")
	public ResponseEntity<String> publicData() {
		System.out.println("/public");
		return new ResponseEntity<String>("!! PUBLIC !!", HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/private")
	public ResponseEntity<String> privateData() {
		System.out.println("/private");
		return new ResponseEntity<String>("!! PRIVATE !!", HttpStatus.ACCEPTED);
	}
}
