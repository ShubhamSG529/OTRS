package com.trs.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.trs.entity.CustomUserDetail;
import com.trs.entity.User;
import com.trs.repo.UserRepo;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepo usersRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> optionalUsers = usersRepository.findByEmail(username);

		optionalUsers.orElseThrow(() -> new UsernameNotFoundException("Username not found"));

		return optionalUsers.map(CustomUserDetail::new).get();
	}
}