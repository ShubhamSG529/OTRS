INSERT INTO role(role) VALUES('ADMIN'),('USER');
INSERT INTO USER(email, NAME, PASSWORD) VALUES('shivamkumar@gmail.com', 'Shivam Kumar', 'admin');
INSERT INTO USER(email, NAME, PASSWORD) VALUES('user@gmail.com', 'user', 'user');
INSERT INTO user_roles (user_user_id,roles_role_id) VALUES(1,1),(2,2);
