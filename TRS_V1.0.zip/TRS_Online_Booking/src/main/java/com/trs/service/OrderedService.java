package com.trs.service;

import java.util.List;

import com.trs.entity.OrderedItem;

public interface OrderedService {

	boolean placeOrder(int restaurantId, int tableNo, String itemDetails, int userId);

	public List<OrderedItem> generateUserBill(int userId);

}
