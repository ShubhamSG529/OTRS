package com.trs.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trs.entity.OrderedItem;

@Repository
public interface OrderedRepo extends JpaRepository<OrderedItem, Integer>{

	List<OrderedItem> findByUserId(int userId);
}
