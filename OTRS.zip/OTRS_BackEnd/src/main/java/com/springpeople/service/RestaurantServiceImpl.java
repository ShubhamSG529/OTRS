package com.springpeople.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.entity.Restaurant;
import com.springpeople.repository.RestaurantRepository;

@Service
public class RestaurantServiceImpl implements RestaurantService {
	@Autowired
	RestaurantRepository restaurantRepository;
	
	@Override
	public List<Restaurant> getAllRestaurants() {
		List<Restaurant> allRestaurants = restaurantRepository.findAll();
		if(allRestaurants.size()!=0){
			return allRestaurants;
		}
		return null;
	}

	@Override
	public Restaurant getRestaurant(int restaurantId) {
		Restaurant restaurant = restaurantRepository.findByRestId(restaurantId);
		if(restaurant!=null){
			return restaurant;
		}
		return null;
	}

}
