package com.springpeople.service;

import java.util.List;

import com.springpeople.entity.Restaurant;

public interface RestaurantService {
	List<Restaurant> getAllRestaurants();

	Restaurant getRestaurant(int restaurantId);
}
