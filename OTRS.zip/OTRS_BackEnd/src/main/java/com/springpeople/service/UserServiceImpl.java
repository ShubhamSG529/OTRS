package com.springpeople.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.entity.User;
import com.springpeople.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;

	@Override
	public User insertUser(User user) {
		User savedUser = null;
		try {
			savedUser = userRepo.save(user);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return savedUser;
	}

	@Override
	public List<User> getAllUser() {
		List<User> allUsers = userRepo.findAll();
		if (allUsers.size() != 0)
			return allUsers;
		else
			return null;
	}

	@Override
	public User getUser(User user) {
		User getUser = userRepo.findByUserEmail(user.getUserEmail());
		System.out.println("getUser: "+getUser);
		if(getUser!=null){
			return getUser;
		}
		return null;
	}
}
