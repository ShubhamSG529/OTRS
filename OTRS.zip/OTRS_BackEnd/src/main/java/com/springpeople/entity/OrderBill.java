package com.springpeople.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class OrderBill {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderBillId;

	@OneToOne
	private Restaurant restaurant;
	@OneToOne
	private OrderedItem orderedItem;
	private Timestamp orderBillingTime;
	private int totalAmount;

	public OrderBill() {
		super();
	}

	public OrderBill(int orderBillId, Restaurant restaurant, OrderedItem orderedItem, Timestamp orderBillingTime,
			int totalAmount) {
		super();
		this.orderBillId = orderBillId;
		this.restaurant = restaurant;
		this.orderedItem = orderedItem;
		this.orderBillingTime = orderBillingTime;
		this.totalAmount = totalAmount;
	}

	public int getOrderBillId() {
		return orderBillId;
	}

	public void setOrderBillId(int orderBillId) {
		this.orderBillId = orderBillId;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	public OrderedItem getOrderedItem() {
		return orderedItem;
	}

	public void setOrderedItem(OrderedItem orderedItem) {
		this.orderedItem = orderedItem;
	}

	public Timestamp getOrderBillingTime() {
		return orderBillingTime;
	}

	public void setOrderBillingTime(Timestamp orderBillingTime) {
		this.orderBillingTime = orderBillingTime;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "OrderBill [orderBillId=" + orderBillId + ", restaurant=" + restaurant + ", orderedItem=" + orderedItem
				+ ", orderBillingTime=" + orderBillingTime + ", totalAmount=" + totalAmount + "]";
	}
}
