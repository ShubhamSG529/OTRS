package com.springpeople.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class RestaurantItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restaurantItemId;

	@ManyToOne/*(mappedBy = "student", cascade = CascadeType.ALL)*/
	private Restaurant restaurant;
	
	@ManyToOne
	private Item item;

	public RestaurantItem() {
		super();
	}

	public RestaurantItem(int restaurantItemId, Restaurant restaurant, Item item) {
		super();
		this.restaurantItemId = restaurantItemId;
		this.restaurant = restaurant;
		this.item = item;
	}

	public int getRestaurantItemId() {
		return restaurantItemId;
	}

	public void setRestaurantItemId(int restaurantItemId) {
		this.restaurantItemId = restaurantItemId;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "RestaurantItem [restaurantItemId=" + restaurantItemId + ", restaurant=" + restaurant + ", item=" + item
				+ "]";
	}
}
