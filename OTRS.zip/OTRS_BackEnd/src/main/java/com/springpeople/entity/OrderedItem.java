package com.springpeople.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class OrderedItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderedItemId;

	@ManyToOne
	private User user;
	@ManyToOne
	private Item item;
	private int quantity;

	public OrderedItem() {
		super();
	}

	public OrderedItem(User user, Item item, int quantity) {
		super();
		this.user = user;
		this.item = item;
		this.quantity = quantity;
	}

	public int getOrderedItemId() {
		return orderedItemId;
	}

	public void setOrderedItemId(int orderedItemId) {
		this.orderedItemId = orderedItemId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "OrderedItem [orderedItemId=" + orderedItemId + ", user=" + user + ", item=" + item + ", quantity="
				+ quantity + "]";
	}
}
