package com.springpeople.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restId;

	@Column(unique = true)
	private String restName;
	private String restAddress;
	@Column(unique = true)
	private String restContact;
	private String imagePath;

	public Restaurant() {

	}

	public Restaurant(String restName, String restAddress, String restContact, String imagePath) {
		super();
		this.restName = restName;
		this.restAddress = restAddress;
		this.restContact = restContact;
		this.imagePath = imagePath;
	}

	public int getRest_id() {
		return restId;
	}

	public void setRest_id(int restId) {
		this.restId = restId;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}

	public String getRestContact() {
		return restContact;
	}

	public void setRestContact(String restContact) {
		this.restContact = restContact;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Override
	public String toString() {
		return "Restaurant [rest_id=" + restId + ", restName=" + restName + ", restAddress=" + restAddress
				+ ", restContact=" + restContact + ", imagePath=" + imagePath + "]";
	}
}
