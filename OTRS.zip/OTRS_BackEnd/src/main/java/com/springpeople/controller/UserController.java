package com.springpeople.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.entity.Restaurant;
import com.springpeople.entity.User;
import com.springpeople.service.RestaurantService;
import com.springpeople.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	RestaurantService restaurantService;
	
	@Value("${queue}")
	String queue;

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> addUser(@RequestBody User user) {
		System.out.println("UserController-addUser");
		User addedUser = userService.insertUser(user);
		if (addedUser != null)
			return new ResponseEntity<User>(addedUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.CONFLICT);
	}
	
	@RequestMapping(value = "/users",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getUsers() {
		System.out.println("UserController-getUsers");
		List<User> allUser = userService.getAllUser();
		if (allUser.size()!=0)
			return new ResponseEntity<List<User>>(allUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value = "/login",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		System.out.println("UserController-loginUsers");
		User getUser = userService.getUser(user);
		if (getUser!=null)
			return new ResponseEntity<User>(getUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value = "/restaurants",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Restaurant>> getRestaurants() {
		System.out.println("UserController-getRestaurants");
		List<Restaurant> allRestaurants = restaurantService.getAllRestaurants();
		if (allRestaurants.size()!=0)
			return new ResponseEntity<List<Restaurant>>(allRestaurants, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<Restaurant>>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value = "/restaurant/{restaurant_id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Restaurant> getSpecificRestaurant(@PathVariable("restaurant_id") int restaurantId) {
		System.out.println("UserController-getSpecificRestaurant");
		Restaurant restaurant = restaurantService.getRestaurant(restaurantId);
		if (restaurant!=null)
			return new ResponseEntity<Restaurant>(restaurant, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<Restaurant>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/public")
	public ResponseEntity<String> publicData() {
		System.out.println("UserController-publicData");
		return new ResponseEntity<String>("public !!", HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/private")
	public ResponseEntity<String> privateData() {
		System.out.println("UserController-privateData");
		return new ResponseEntity<String>("private !!", HttpStatus.ACCEPTED);
	}
}
