insert into role(role) values('ADMIN'),('USER');

insert into user(active, email,contact, name, password) values(1, 'shubhamsg@gmail.com','8964005911', 'ShubhamSG', 'admin');

insert into user_roles values(1,1);