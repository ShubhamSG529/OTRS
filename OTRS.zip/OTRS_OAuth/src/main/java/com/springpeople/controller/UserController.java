package com.springpeople.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.entity.User;
import com.springpeople.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> addUser(@RequestBody User user) {
		System.out.println("UserController-addUser");
		Optional<User> getUser = userService.isExist(user.getUserEmail());
		if (getUser.isPresent())
			return ResponseEntity.status(HttpStatus.CONFLICT).build();// 409
		else
			return new ResponseEntity<User>(userService.addUser(user), HttpStatus.CREATED);// 201
	}

	@RequestMapping(value = "/user/{email}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> getUser(@PathVariable(name = "email") String email) {
		System.out.println("UserController-getUser");
		User user = userService.getUserByEmail(email + ".com");
		if (user != null)
			return new ResponseEntity<User>(user, HttpStatus.ACCEPTED);// 202
		else
			return new ResponseEntity<User>(user, HttpStatus.NOT_FOUND);// 404
	}

	@RequestMapping(value = "/user", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getUsers() {
		System.out.println("UserController-getUsers");
		List<User> allUsers = userService.getAllUsers();
		if (allUsers.size() == 0) {
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);// 404
		} else {
			return new ResponseEntity<List<User>>(allUsers, HttpStatus.ACCEPTED);// 202
		}
	}
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public ResponseEntity<String> hello() {
		System.out.println("UserController-hello");
		return new ResponseEntity<String>("Hello World !!!",HttpStatus.ACCEPTED);// 202
	}
}
