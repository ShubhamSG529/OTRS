package com.springpeople;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class ApplicationResource {

	
	@RequestMapping("/user")
	public Principal user(Principal principalUser) {
		System.out.println("ApplicationResource User Principal :" + principalUser);
		return principalUser;
	}

	@CrossOrigin
	@PreAuthorize("hasAnyRole('ADMIN')")
	@GetMapping
	public String hello() {
		System.out.println("ApplicationResource Hello Resource");
		return "Hello World!!";
	}

}
