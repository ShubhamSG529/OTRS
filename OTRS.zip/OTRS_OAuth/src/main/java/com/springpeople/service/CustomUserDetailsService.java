package com.springpeople.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.springpeople.entity.CustomUserDetails;
import com.springpeople.entity.User;
import com.springpeople.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository usersRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> optionalUsers = usersRepository.findByUserEmail(username);

		optionalUsers.orElseThrow(() -> new UsernameNotFoundException("Username not found"));
		
		return optionalUsers.map(CustomUserDetails::new).get();
	}
}