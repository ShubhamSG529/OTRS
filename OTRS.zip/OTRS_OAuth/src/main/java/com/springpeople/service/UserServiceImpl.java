package com.springpeople.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.springpeople.entity.CustomUserDetails;
import com.springpeople.entity.User;
import com.springpeople.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;

	@Override
	public User addUser(User user) {
		return userRepo.save(user);
	}

	@Override
	public User getUserByEmail(String userEmail) {
		Optional<User> user = userRepo.findByUserEmail(userEmail);
		user.orElseThrow(() -> new UsernameNotFoundException("User not found"));
		return user.map(CustomUserDetails::new).get();
	}

	@Override
	public Optional<User> isExist(String userEmail) {
		return userRepo.findByUserEmail(userEmail);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}
}
