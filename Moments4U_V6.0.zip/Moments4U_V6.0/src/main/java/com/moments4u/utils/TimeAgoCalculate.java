package com.moments4u.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class TimeAgoCalculate {
	/**
	 * Calculate How much time ago that post was updated
	 * 
	 * @param pastTime
	 */
	public static String calculate(String pastTime) {
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

			Date currentDate = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
			Date pastDate = simpleDateFormat.parse(pastTime);

			long diff = currentDate.getTime() - pastDate.getTime();
			if (diff > 0) {
				long difference = Math.abs(currentDate.getTime() - pastDate.getTime());

				long daysAgo = TimeUnit.MILLISECONDS.toDays(difference);
				long hoursAgo = Math
						.abs(TimeUnit.MILLISECONDS.toDays(difference) * 24 - TimeUnit.MILLISECONDS.toHours(difference));
				long minutsAgo = Math.abs(
						TimeUnit.MILLISECONDS.toHours(difference) * 60 - TimeUnit.MILLISECONDS.toMinutes(difference));
				long secondsAgo = Math.abs(
						TimeUnit.MILLISECONDS.toMinutes(difference) * 60 - TimeUnit.MILLISECONDS.toSeconds(difference));

				if (daysAgo == 1) {
					return "YESTERDAY";
				} else if (daysAgo == 0) {
					if (hoursAgo != 0) {
						return hoursAgo + " hrs " + minutsAgo + " mins " + secondsAgo + " sec ago";
					} else if (hoursAgo == 0) {
						if (minutsAgo != 0) {
							return minutsAgo + " mins " + secondsAgo + " sec ago";
						} else if (minutsAgo == 0) {
							return secondsAgo + " sec ago";
						}
					}
				} else if (daysAgo > 1) {
					return pastDate.toString();
				}
			} else if (diff == 0) {
				return "NOW";
			} else {
				return "FUTURE";
			}
		} catch (Exception e) {
			return "Exception :" + e.getMessage();
		}
		return pastTime;
	}
}
