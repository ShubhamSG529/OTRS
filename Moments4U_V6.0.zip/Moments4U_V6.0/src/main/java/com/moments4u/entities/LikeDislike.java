package com.moments4u.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class LikeDislike {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer likeDislikeId;

	@ManyToOne
	private NewsFeed newsFeed;

	@ManyToOne
	private User user;
	private String likeStatus;
	private String dislikeStatus;

	public Integer getLikeDislikeId() {
		return likeDislikeId;
	}

	public void setLikeDislikeId(Integer likeDislikeId) {
		this.likeDislikeId = likeDislikeId;
	}

	public NewsFeed getNewsFeed() {
		return newsFeed;
	}

	public void setNewsFeed(NewsFeed newsFeed) {
		this.newsFeed = newsFeed;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getLikeStatus() {
		return likeStatus;
	}

	public void setLikeStatus(String likeStatus) {
		this.likeStatus = likeStatus;
	}

	public String getDislikeStatus() {
		return dislikeStatus;
	}

	public void setDislikeStatus(String dislikeStatus) {
		this.dislikeStatus = dislikeStatus;
	}

	@Override
	public String toString() {
		return "LikeDislike [likeDislikeId=" + likeDislikeId + ", newsFeed=" + newsFeed + ", user=" + user
				+ ", likeStatus=" + likeStatus + ", dislikeStatus=" + dislikeStatus + "]";
	}

}
