package com.moments4u.exception;

public class NoMoreProjectsAvailableException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoMoreProjectsAvailableException(String msg) {
		super(msg);
	}

}
