package com.moments4u.exception;

public class NoMoreUserAvailableException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoMoreUserAvailableException(String msg) {
		super(msg);
	}
}
