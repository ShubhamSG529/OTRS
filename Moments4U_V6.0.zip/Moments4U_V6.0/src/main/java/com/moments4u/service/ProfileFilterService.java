package com.moments4u.service;

import java.util.List;

import com.moments4u.entities.User;
import com.moments4u.utils.ProfileFilter;

public interface ProfileFilterService {

	List<User> filterAllProfile(ProfileFilter profileFilter);

}
