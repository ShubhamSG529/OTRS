package com.moments4u.service;

import com.moments4u.entities.ContactUs;

public interface ContactUsService {

	ContactUs saveContactUs(ContactUs contactUs);

}
