package com.moments4u.service;

import java.util.List;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.entities.NewsFeed;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.NoDataAvailableNewsFeed;

public interface NewsFeedService {

	List<NewsFeedDto> getAllNewsFeeds(Integer userId,Integer startingIndex) throws InvalidUserDetailsException,NoDataAvailableNewsFeed;

	NewsFeed postNewsFeed(NewsFeed newsFeed) throws InvalidUserDetailsException,Exception;

	NewsFeedDto actionOnNewsFeeds(NewsFeed newsFeed, String action);
}
