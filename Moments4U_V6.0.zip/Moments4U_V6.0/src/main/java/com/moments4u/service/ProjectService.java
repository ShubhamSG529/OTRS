package com.moments4u.service;

import java.util.List;

import com.moments4u.dto.ProjectDto;
import com.moments4u.entities.User;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.NoMoreProjectsAvailableException;

public interface ProjectService {

	List<ProjectDto> getAllProjects(User user) throws NoMoreProjectsAvailableException, InvalidUserDetailsException;

}
