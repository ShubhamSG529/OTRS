package com.moments4u.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.dto.ProjectDto;
import com.moments4u.entities.Project;
import com.moments4u.entities.User;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.NoMoreProjectsAvailableException;
import com.moments4u.repository.ProjectRepository;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	UserRepository userRepository;

	@Override
	public List<ProjectDto> getAllProjects(User user) throws NoMoreProjectsAvailableException, InvalidUserDetailsException {
		User getUserById = userRepository.findByUserId(user.getUserId());

		if (getUserById != null) {
			List<Project> projectList = projectRepository.findByUser_UserId(user.getUserId());
			if (projectList.size() != 0) {
				List<ProjectDto> projectDtoList = new ArrayList<ProjectDto>();
				for (Project project : projectList) {
					ProjectDto projectDto = new ProjectDto();
					projectDto.setProjectId(project.getProjectId());
					projectDto.setDateTime(new SimpleDateFormat("dd-MM-YYYY").format(project.getDateTime()));
					
					String[] splitedFileName = project.getFilePath().split("/");
					projectDto.setFileName(splitedFileName[splitedFileName.length-1]);
					
					projectDto.setFormat(project.getFormat());
					projectDto.setStatus(project.getStatus());
					projectDto.setUserName(project.getUser().getUserName());

					projectDtoList.add(projectDto);
				}

				return projectDtoList;
			} else {
				throw new NoMoreProjectsAvailableException("NO MORE PROJECTS AVAILABLE");
			}
		}else{
			throw new InvalidUserDetailsException("YOU ARE SEARCHING PROJECTS FOR INVALID USER");
		}		
	}
}
