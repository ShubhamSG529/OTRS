package com.moments4u.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.entities.ContactUs;
import com.moments4u.repository.ContactUsRepository;
import com.moments4u.service.ContactUsService;

@Service
public class ContactUsServiceImpl implements ContactUsService {

	@Autowired
	ContactUsRepository contactUsRepo;

	@Override
	public ContactUs saveContactUs(ContactUs contactUs) {
		return contactUsRepo.save(contactUs);
	}

}
