package com.moments4u.serviceimpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.moments4u.dto.UserDto;
import com.moments4u.entities.Follower;
import com.moments4u.entities.Project;
import com.moments4u.entities.User;
import com.moments4u.exception.DuplicateEmailException;
import com.moments4u.exception.DuplicatePhoneNumberException;
import com.moments4u.exception.InvalidEmailFormatException;
import com.moments4u.exception.InvalidGenderTypeException;
import com.moments4u.exception.InvalidOnlineStatusTypeException;
import com.moments4u.exception.InvalidPasswordFormatException;
import com.moments4u.exception.InvalidPhoneNumberException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.InvalidUserNameException;
import com.moments4u.exception.NoMoreUserAvailableException;
import com.moments4u.repository.FollowerRepository;
import com.moments4u.repository.ProjectRepository;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;

	@Autowired
	FollowerRepository followerRepository;

	@Autowired
	ProjectRepository projectRepository;

	@Override
	public User signinUser(User user) throws InvalidUserDetailsException {
		try {
			user = validateEmailPassword(user);
			user = userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
			if (user != null) {
				user.setActive(1);
				userRepository.save(user);
				return user;
			} else {
				throw new InvalidUserDetailsException("DETAILS PROVIDED BY YOU IS INCORRECT");
			}
		} catch (InvalidUserDetailsException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
	}

	private User validateEmailPassword(User user) throws InvalidUserDetailsException {
		if (!(user.getEmail().trim().equals("") || user.getPassword().trim().equals("")
				|| user.getPassword().trim().length() < 8)) {

			if (userRepository.findByEmail(user.getEmail()) == null) {
				throw new InvalidUserDetailsException("USER EMAIL DOESN'T EXIST");
			}
		} else {
			throw new InvalidUserDetailsException("IMPROPER INFORMATION");
		}
		return user;
	}

	@Override
	public User signupUser(User user) throws DuplicateEmailException, DuplicatePhoneNumberException,
			InvalidPhoneNumberException, InvalidGenderTypeException, InvalidOnlineStatusTypeException,
			InvalidUserNameException, InvalidEmailFormatException, InvalidPasswordFormatException {

		try {
			user = validationUserObject(user);
		} catch (InvalidPhoneNumberException e1) {
			throw e1;
		} catch (InvalidGenderTypeException e1) {
			throw e1;
		}

		try {
			if (userRepository.findByEmail(user.getEmail()) != null)
				throw new DuplicateEmailException("DUPLICATE EMAIL");

			if (userRepository.findByPhoneNumber(user.getPhoneNumber()) != null)
				throw new DuplicatePhoneNumberException("DUPLICATE PHONE NUMBER");

			// Password encryption
			// user.setPassword(new
			// StrongPasswordEncryptor().encryptPassword(user.getPassword()));

			return userRepository.save(user);
		} catch (Exception e) {
			throw e;
		}
	}

	private User validationUserObject(User user)
			throws InvalidPhoneNumberException, InvalidGenderTypeException, InvalidOnlineStatusTypeException,
			InvalidUserNameException, InvalidEmailFormatException, InvalidPasswordFormatException {

		System.out.println("user: " + user);
		String phoneNumber = user.getPhoneNumber();
		String phoneNumberPatternString = "^[789]((\\+)?(\\d{2}[-]))?(\\d{9}){1}?$";
		Pattern compilePhoneNumber = Pattern.compile(phoneNumberPatternString, Pattern.CASE_INSENSITIVE);
		Matcher matcherPhoneNumber = compilePhoneNumber.matcher(phoneNumber);
		if (!matcherPhoneNumber.find()) {
			throw new InvalidPhoneNumberException("INVALID PHONE NUMBER FORMAT");
		}

		String email = user.getEmail();
		String emailPatternString = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
		Pattern compileEmail = Pattern.compile(emailPatternString, Pattern.CASE_INSENSITIVE);
		Matcher matcherEmail = compileEmail.matcher(email);
		if (!matcherEmail.find()) {
			throw new InvalidEmailFormatException("INVALID EMAIL FORMAT");
		}

		String password = user.getPassword();
		if (password.trim().length() < 8) {
			throw new InvalidPasswordFormatException("PASSWORD LENGTH SHOULD BE GREATER THAN OR EQUAL TO 8");
		}
		String passwordPatternString = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$";
		Pattern compilePassword = Pattern.compile(passwordPatternString, Pattern.CASE_INSENSITIVE);
		Matcher matcherPassword = compilePassword.matcher(password);
		if (!matcherPassword.find()) {
			throw new InvalidPasswordFormatException("INVALID PASSWORD FORMAT");
		}

		if (!(user.getGender().equalsIgnoreCase("MALE") || user.getGender().equalsIgnoreCase("FEMALE"))) {
			throw new InvalidGenderTypeException("INVALID GENDER TYPE");
		}

		if (user.getUserName().length() > 25) {
			throw new InvalidUserNameException("INVALID USER NAME");
		}

		if (!(user.getOnlineStatus().equalsIgnoreCase("OFFLINE")
				|| user.getOnlineStatus().equalsIgnoreCase("ONLINE"))) {
			throw new InvalidOnlineStatusTypeException("INVALID ONLINE STATUS TYPE");
		}

		return user;
	}

	@Override
	public User updateUserProfile(User user) throws InvalidUserDetailsException {
		User getUserByEmail = userRepository.findByEmail(user.getEmail());
		if (getUserByEmail != null) {
			user.setUserId(getUserByEmail.getUserId());
			try {
				getUserByEmail.setAge(user.getAge());
				getUserByEmail.setDescription(user.getDescription());
				getUserByEmail.setUserName(user.getUserName());

				return userRepository.save(getUserByEmail);
			} catch (Exception e) {
				System.out.println("Exception Occured: " + e);
				throw e;
			}
		} else {
			throw new InvalidUserDetailsException("USER EMAIL DOESN'T EXIST");
		}
	}

	@Override
	public UserDto getUser(User user) throws InvalidUserDetailsException {
		try {
			User getUserById = userRepository.findByUserId(user.getUserId());

			if (getUserById != null) {
				UserDto userDto = new UserDto();
				userDto.setUserObject(getUserById);

				ArrayList<Follower> followingUsers = followerRepository.findByFUser_UserId(getUserById.getUserId());
				ArrayList<User> following = new ArrayList<User>();

				for (int i = 0; i < followingUsers.size(); i++) {
					following.add(followingUsers.get(i).getFollowingUser());
				}
				ArrayList<Follower> fUsers = followerRepository.findByFollowingUser_UserId(getUserById.getUserId());
				ArrayList<User> followers = new ArrayList<User>();
				for (int i = 0; i < fUsers.size(); i++) {
					followers.add(fUsers.get(i).getfUser());
				}

				userDto.setFollowing(following);
				userDto.setFollowers(followers);

				ArrayList<Project> projects = projectRepository.findByUser_UserId(getUserById.getUserId());
				System.out.println("projects::  " + projects);

				userDto.setProjects(projects);
				return userDto;
			} else {
				throw new InvalidUserDetailsException("USER DOESN'T EXIST");
			}
		} catch (Exception e) {
			throw new InvalidUserDetailsException("USER DOESN'T EXIST");
		}
	}

	@Override
	public List<User> getAllUser(int startIndex) throws NoMoreUserAvailableException {
		int endIndex = startIndex + 15;
		@SuppressWarnings("deprecation")
		Pageable limit = new PageRequest(0, endIndex);
		List<User> findByActiveIn = userRepository.findByActiveIn(Arrays.asList(1, 0), limit);

		if (findByActiveIn.size() > 0 && startIndex <= findByActiveIn.size()) {
			System.out.println("getAllUser:" + startIndex + "_" + findByActiveIn.size());
			List<User> allUser = new ArrayList<User>();
			for (int index = startIndex; index < findByActiveIn.size(); index++) {
				allUser.add(findByActiveIn.get(index));
			}
			if (allUser.size() > 0) {
				return allUser;
			} else {
				throw new NoMoreUserAvailableException("No More User Data Available");
			}
		} else {
			throw new NoMoreUserAvailableException("No More User Data Available");
		}
	}

	@Override
	public User logout(User user) {
		user = userRepository.findByUserId(user.getUserId());
		user.setActive(0);
		return userRepository.save(user);
	}
}
