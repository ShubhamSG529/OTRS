package com.moments4u.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.moments4u.entities.User;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.ProfileFilterService;
import com.moments4u.utils.ProfileFilter;

@Service
public class ProfileFilterServiceImpl implements ProfileFilterService {

	@Autowired
	UserRepository UserRepo;

	@Override
	public List<User> filterAllProfile(ProfileFilter profileFilter) {
		List<User> users = new ArrayList<User>();
		System.out.println("profileFilter : " + profileFilter);
		
		return users;
	}

}
