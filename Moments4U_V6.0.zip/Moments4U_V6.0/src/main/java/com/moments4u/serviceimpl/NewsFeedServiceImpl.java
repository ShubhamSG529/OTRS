package com.moments4u.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.moments4u.dto.NewsFeedDto;
import com.moments4u.entities.LikeDislike;
import com.moments4u.entities.NewsFeed;
import com.moments4u.entities.User;
import com.moments4u.exception.ApplicationException;
import com.moments4u.exception.InvalidUserDetailsException;
import com.moments4u.exception.NoDataAvailableNewsFeed;
import com.moments4u.repository.LikeDislikeRepository;
import com.moments4u.repository.NewsFeedRepository;
import com.moments4u.repository.UserRepository;
import com.moments4u.service.NewsFeedService;
import com.moments4u.utils.TimeAgoCalculate;

@Service
public class NewsFeedServiceImpl implements NewsFeedService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	NewsFeedRepository newsFeedRepository;

	@Autowired
	LikeDislikeRepository likeDislikeRepository;

	public static final String INVALID_USER_DETAILS = "InvalidUserDetailsException SEARCHING BY USERID ";

	@Override
	public List<NewsFeedDto> getAllNewsFeeds(Integer userId, Integer startingIndex)
			throws InvalidUserDetailsException, NoDataAvailableNewsFeed {
		List<NewsFeedDto> newsFeedDtos = new ArrayList<NewsFeedDto>();
		boolean flag = false;
		if (userId != null) {
			if (userId != 0) {
				User user = userRepository.findByUserId(userId);
				if (user != null) {
					flag = true;
				} else {
					throw new InvalidUserDetailsException("USER DOESN'T EXIST");
				}
			} else {
				flag = false;
			}

			List<NewsFeed> newsFeeds = new ArrayList<NewsFeed>();
			int endIndex = startingIndex + 10;
			@SuppressWarnings("deprecation")
			Pageable limit = new PageRequest(0, endIndex);
			if (flag) {
				newsFeeds = newsFeedRepository.findByUser_UserIdOrderByDateTimeDesc(userId, limit);
			} else {
				newsFeeds = newsFeedRepository.findAllByOrderByDateTimeDescNewsFeedIdAsc(limit);
			}
			System.out.println("getAllNewsFeeds_" + startingIndex + "_" + newsFeeds.size());
			if (newsFeeds.size() != 0 && startingIndex <= newsFeeds.size()) {
				for (int index = startingIndex; index < newsFeeds.size(); index++) {
					NewsFeed newsFeed = newsFeeds.get(index);
					NewsFeedDto newsFeedDto = new NewsFeedDto();
					newsFeedDto.setNewsFeedId(newsFeed.getNewsFeedId());
					newsFeedDto.setUserName(newsFeed.getUser().getUserName());
					newsFeedDto.setUserProfPicPath(newsFeed.getUser().getProfilePicturePath());
					newsFeedDto.setGender(newsFeed.getUser().getGender());
					newsFeedDto.setActive(newsFeed.getUser().getActive());
					newsFeedDto.setPost(newsFeed.getPost());
					newsFeedDto.setDateTime(new SimpleDateFormat("MMMM dd YYYY").format(newsFeed.getDateTime()));

					String timeAgo = TimeAgoCalculate
							.calculate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(newsFeed.getDateTime()));
					newsFeedDto.setTimeAgo(timeAgo);

					Integer likeCount = likeDislikeRepository
							.findByNewsFeed_newsFeedIdAndLikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES").size();
					Integer dislikeCount = likeDislikeRepository
							.findByNewsFeed_newsFeedIdAndDislikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES")
							.size();

					newsFeedDto.setDislikeCount(dislikeCount);
					newsFeedDto.setLikeCount(likeCount);

					newsFeedDtos.add(newsFeedDto);
				}
				return newsFeedDtos;
			} else {
				throw new NoDataAvailableNewsFeed("NO MORE NEWSFEED DATA AVAILABLE");
			}
		} else {
			throw new InvalidUserDetailsException(INVALID_USER_DETAILS);
		}
	}

	@Override
	public NewsFeed postNewsFeed(NewsFeed newsFeed)
			throws InvalidUserDetailsException, ApplicationException, Exception {
		try {
			User user = userRepository.findByUserId(newsFeed.getUser().getUserId());
			if (user != null) {
				if (newsFeed.getPost() != null) {
					if (newsFeed.getPost().trim().equals("")) {
						throw new ApplicationException("NEWSFEED POST CANN'T BE EMPTY");
					}
					NewsFeed savedNewsFeed = newsFeedRepository.save(newsFeed);
					if (savedNewsFeed != null) {
						savedNewsFeed.setUser(user);
						return savedNewsFeed;
					} else {
						throw new ApplicationException("NEWSFEED POST DOESN'T SAVED SOMETHING WENT WRONG");
					}
				} else {
					throw new ApplicationException("NEWSFEED POST CANN'T BE NULL");
				}
			} else {
				throw new InvalidUserDetailsException("INVALID USER ID");
			}
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public NewsFeedDto actionOnNewsFeeds(NewsFeed newsFeed, String action) {
		System.out.println(
				"--------------------------------------------------------------------------------------------------------------------------------------------------");
		LikeDislike likeDislike = new LikeDislike();
		likeDislike.setNewsFeed(newsFeed);
		likeDislike.setUser(newsFeed.getUser());

		if (action.contains("dislike")) {
			likeDislike.setDislikeStatus("YES");
			likeDislike.setLikeStatus("NO");
		} else if (action.contains("like")) {
			likeDislike.setDislikeStatus("NO");
			likeDislike.setLikeStatus("YES");
		}

		try {
			/*
			 * List<LikeDislike> getLikeDislikeObjects = likeDislikeRepository
			 * .findByNewsFeed_newsFeedIdAndUser_userIdAndLikeStatusAndDislikeStatus
			 * (newsFeed.getNewsFeedId(), newsFeed.getUser().getUserId(),
			 * likeDislike.getLikeStatus(), likeDislike.getDislikeStatus());
			 */

			List<LikeDislike> getLikeDislikeObjects = likeDislikeRepository
					.findByNewsFeed_newsFeedIdAndUser_userId(newsFeed.getNewsFeedId(), newsFeed.getUser().getUserId());
			if (getLikeDislikeObjects.size() == 0) {
				likeDislikeRepository.save(likeDislike);
			} else if (getLikeDislikeObjects.size() == 1) {
				likeDislikeRepository.deleteById(getLikeDislikeObjects.get(0).getLikeDislikeId());
				likeDislikeRepository.save(likeDislike);
			}
		} catch (Exception e) {
			System.out.println("actionOnNewsFeeds Exception: " + e);
		}

		NewsFeedDto newsFeedDto = new NewsFeedDto();
		newsFeedDto.setNewsFeedId(newsFeed.getNewsFeedId());

		Integer likeCount = likeDislikeRepository
				.findByNewsFeed_newsFeedIdAndLikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES").size();
		Integer dislikeCount = likeDislikeRepository
				.findByNewsFeed_newsFeedIdAndDislikeStatusIgnoreCase(newsFeed.getNewsFeedId(), "YES").size();

		newsFeedDto.setDislikeCount(dislikeCount);
		newsFeedDto.setLikeCount(likeCount);

		return newsFeedDto;
	}
}
