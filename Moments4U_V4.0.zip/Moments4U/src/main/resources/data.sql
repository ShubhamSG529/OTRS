INSERT INTO USER (email,gender,online_status,PASSWORD,phone_number,category,profession,user_name,age) VALUES
("alex@gmail.com","Male","Offline","User123@","1111111111","Artist","Photographer","alex merlin",21),
("essenceholland@gmail.com","FeMale","Offline","User123@","2222222222","Organiser","Singer","Essence Holland",22),
("charliemcgee@gmail.com","Male","Offline","User123@","3333333333","Artist","Musicians","Charlie Mcgee",31),
("william@gmail.com","FeMale","Offline","User123@","4444444444","Organiser","PlayBack Singer","William Yusuf",11),
("irenepierce@gmail.com","Male","Offline","User123@","5555555555","Artist","Musicians","Irene Pierce",25),
("erikaarellano@gmail.com","FeMale","Offline","User123@","6666666666","Organiser","Poet","Erika Arellano",29),
("tiffanyconley@gmail.com","Male","Offline","User123@","7777777777","Artist","Photographer","Tiffany Conley",33),
("aaliyahwalls@gmail.com","FeMale","Offline","User123@","8888888888","Organiser","Poet","Aaliyah Walls",42),
("edwinhale@gmail.com","Male","Offline","User123@","9999999999","Artist","Musicians","Edwin Hale",35),
("shubhamsg@gmail.com","Male","Offline","User123@","1010101010","Organiser","Singer","Shubham Gupta",23);

INSERT INTO USER (email,gender,online_status,PASSWORD,phone_number,category,profession,user_name) VALUES
("aronhank@gmail.com","FeMale","Offline","User123@","7777773468","Artist","PlayBack Singer","Aaron, Hank"),
("abagnalefrank@gmail.com","FeMale","Offline","User123@","8888823786","Organiser","Musicians","Abagnale, Frank"),
("abbeyedward@gmail.com","Male","Offline","User123@","9999997594","Artist","Poet","Abbey, Edward"),
("abelsonhal@gmail.com","FeMale","Offline","User123@","1010107695","Organiser","PlayBack Singer","Abelson, Hal");

INSERT INTO follower (f_user_user_id,following_user_user_id) VALUES
(1,3),(1,5),(1,7),(1,9),(2,4),(2,6),(2,8),(2,10),(3,1),(3,5),(3,7),(3,9),(4,6),(4,8),(4,10),(6,8),(6,10),(7,9),(8,10),(10,1),(10,3),(10,5),(10,6),(10,7),(10,9);

INSERT INTO news_feed (post,user_user_id) VALUES
("hello,I am user 1",1),
("hello,I am new user",2),
("hello,I am new user",3),
("hello,I am new user",4),
("hello,I am new user",5),
("hello,I am new user",6),
("hello,I am new user",8),
("hello,I am new user",7),
("hello,I am new user",9),
("Slow-motion movie of the Crab Pulsar, taken with OES Single-Photon-Camera.
File:The Crab Nebula - A Flickering X-ray Candle.ogv
Data from orbiting observatories show unexpected variations in the Crab Nebula's X-ray output, likely tied to the environment around its central neutron star.
File:NASA's Fermi Spots 'Superflares' in the Crab Nebula.ogv
NASA's Fermi spots 'superflares' in the Crab Nebula.
At the center of the Crab Nebula are two faint stars, one of which is the star responsible for the existence of the nebula. 
It was identified as such in 1942, when Rudolf Minkowski found that its optical spectrum was extremely unusual.
The region around the star was found to be a strong source of radio waves in 1949[38] and X-rays in 1963, 
and was identified as one of the brightest objects in the sky in gamma rays in 1967.Then, in 1968, 
the star was found to be emitting its radiation in rapid pulses, becoming one of the first pulsars to be discovered.
Pulsars are sources of powerful electromagnetic radiation, emitted in short and extremely regular pulses many times a second. 
They were a great mystery when discovered in 1967, and the team who identified the first one considered the possibility that 
it could be a signal from an advanced civilization.[41] However, the discovery of a pulsating radio source in the centre of 
the Crab Nebula was strong evidence that pulsars were formed by supernova explosions.[42] They now are understood to be rapidly 
rotating neutron stars, whose powerful magnetic field concentrates their radiation emissions into narrow beams.",10),
("In the 1960s, because of the prediction and discovery of pulsars, the Crab Nebula again became
 a major centre of interest. It was then that Franco Pacini predicted the existence of the Crab 
Pulsar for the first time, which would explain the brightness of the cloud. The star was observed shortly afterwards in 1968.
The discovery of the Crab pulsar, and the knowledge of its exact age (almost to the day) allows for the verification of 
basic physical properties of these objects, such as characteristic age and spin-down luminosity, the orders of magnitude 
involved (notably the strength of the magnetic field), along with various aspects related to the dynamics of the remnant.
The role of this supernova to the scientific understanding of supernova remnants was crucial, as no other historical supernova 
created a pulsar whose precise age is known for certain. The only possible exception to this rule would be SN 1181 whose supposed 
remnant, 3C 58, is home to a pulsar, but its identification using Chinese observations from 1181 is sometimes contested",10),
("At the center of the nebula lies the Crab Pulsar, a neutron star 28–30 kilometres (17–19 mi) 
across with a spin rate of 30.2 times per second,[6] which emits pulses of radiation from gamma 
rays to radio waves. At X-ray and gamma ray energies above 30 keV, the Crab Nebula is generally 
the brightest persistent source in the sky, with measured flux extending to above 10 TeV. 
The nebula's radiation allows for the detailed studying of celestial bodies that occult it. 
In the 1950s and 1960s, the Sun's corona was mapped from observations of the Crab Nebula's radio waves passing through it,
 and in 2003, the thickness of the atmosphere of Saturn's moon Titan was measured as it blocked out X-rays from the nebula.",10),
("The Crab Nebula (catalogue designations M1, NGC 1952, Taurus A) is a supernova remnant in the 
constellation of Taurus. The now-current name is due to William Parsons, who observed the object in 
1840 using a 36-inch telescope and produced a drawing that looked somewhat like a crab.[5] Corresponding 
to a bright supernova recorded by Chinese astronomers in 1054, the nebula was observed later by English 
astronomer John Bevis in 1731. The nebula was the first astronomical object identified with a historical
supernova explosion.At an apparent magnitude of 8.4, comparable to that of Saturn's moon Titan, it is not
visible to the naked eye but can be made out using binoculars under favourable conditions. The nebula lies 
in the Perseus Arm of the Milky Way galaxy, at a distance of about 2.0 kiloparsecs (6,500 ly) from Earth. 
It has a diameter of 3.4 parsecs (11 ly), corresponding to an apparent diameter of some 7 arcminutes, and 
is expanding at a rate of about 1,500 kilometres per second (930 mi/s), or 0.5% of the speed of light.",10);

INSERT INTO like_dislike (dislike_status,like_status,news_feed_news_feed_id,user_user_id) VALUES
("NO","YES",2,1),
("YES","NO",11,2),
("YES","NO",10,4),
("NO","YES",10,5),
("NO","YES",10,9),
("NO","YES",10,6),
("NO","YES",10,2),
("YES","NO",10,7),
("NO","YES",11,3),
("NO","YES",5,10),
("YES","NO",11,7),
("YES","NO",2,10);

INSERT INTO COMMENT (COMMENT,news_feed_news_feed_id,user_user_id) VALUES
("Nice Post",2,1),
("Worst Post",2,2),
("Nice Post",3,3),
("Worst Post",3,1),
("Nice Post",6,3),
("Worst Post",6,4),
("Nice Post",7,9),
("Worst Post",7,9);

INSERT INTO project (file_path,FORMAT,STATUS,user_user_id) VALUES
("./uploads/img_0.jpg","jpg","Uploaded",1),
("./uploads/img_1.jpg","jpg","Uploaded",1),
("./uploads/img_2.jpg","jpg","Uploaded",2),
("./uploads/img_3.jpg","jpg","Uploaded",3),
("./uploads/img_4.jpg","jpg","Uploaded",4),
("./uploads/img_5.jpg","jpg","Uploaded",5),
("./uploads/img_6.jpg","jpg","Uploaded",6),
("./uploads/img_7.jpg","jpg","Uploaded",7),
("./uploads/img_8.jpg","jpg","Uploaded",8),
("./uploads/img_9.jpg","jpg","Uploaded",9),
("./uploads/img_0.jpg","jpg","Uploaded",10),
("./uploads/img_1.jpg","jpg","Uploaded",10),
("./uploads/img_2.jpg","jpg","Uploaded",10),
("./uploads/img_3.jpg","jpg","Uploaded",10),
("./uploads/img_4.jpg","jpg","Uploaded",10),
("./uploads/img_5.jpg","jpg","Uploaded",10),
("./uploads/img_6.jpg","jpg","Uploaded",10),
("./uploads/img_7.jpg","jpg","Uploaded",10),
("./uploads/img_8.jpg","jpg","Uploaded",10),
("./uploads/img_9.jpg","jpg","Uploaded",10),
("./uploads/img_10.jpg","jpg","Uploaded",10),

("./uploads/img_11.jpg","mp4","Uploaded",10),
("./uploads/img_12.jpg","mp4","Uploaded",10),
("./uploads/img_13.jpg","mp4","Uploaded",10),
("./uploads/img_14.jpg","mp4","Uploaded",10),
("./uploads/img_15.jpg","mp4","Uploaded",10),
("./uploads/img_16.jpg","mp4","Uploaded",10),
("./uploads/img_17.jpg","mp4","Uploaded",10),
("./uploads/img_18.jpg","mp4","Uploaded",10),
("./uploads/img_19.jpg","mp4","Uploaded",10),
("./uploads/img_20.jpg","mp4","Uploaded",10);














