package com.moments4u.dto;

public class ProjectDto {
	private Integer projectId;
	private String userName;
	private String format;
	private String fileName;
	private String dateTime;
	private String status;

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ProjectDto [projectId=" + projectId + ", userName=" + userName + ", format=" + format + ", fileName="
				+ fileName + ", dateTime=" + dateTime + ", status=" + status + "]";
	}

}
