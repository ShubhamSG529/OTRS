package com.moments4u.exception;

public class NoDataAvailableNewsFeed extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoDataAvailableNewsFeed(String msg) {
		super(msg);
	}

}
