package com.moments4u.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.moments4u.entities.Follower;

@Repository
public interface FollowerRepository extends JpaRepository<Follower, Integer> {

	ArrayList<Follower> findByFUser_UserId(Integer userId);

	ArrayList<Follower> findByFollowingUser_UserId(Integer userId);


}
