function registerPage(){
    document.getElementById("login_div").style.display="none";
    document.getElementById("register_div").style.display="inline";
}
function SignInPage(){
    document.getElementById("login_div").style.display="inline";
    document.getElementById("register_div").style.display="none";
}
function registerUser(){
    var userName = document.getElementById("register_user_name").value;
    var userEmail = document.getElementById("register_email").value;
    var password = document.getElementById("register_password").value;
    var repassword = document.getElementById("register_repassword").value;

    var json = userJson(userName, userEmail,password);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
                                    if (this.readyState == 4 && this.status == 202) {
                                        //alert(this.responseText);
                                        document.cookie = "user_object=" + this.responseText + ";";
										window.location = 'resto.html';
                                    }
                                };
    xhttp.open("POST", "http://localhost:8082/signup", true);
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(json);
}
function loginUser(){
    var email = document.getElementById("login_email").value;
    var password = document.getElementById("login_password").value;

    var json = "{ \"email\":\"" + email + "\", \"password\":\"" + password + "\"}";
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
                                    if (this.readyState == 4 && this.status == 202) {
                                        //alert(this.responseText);
                                        document.cookie = "user_object=" + this.responseText + ";";
										window.location = 'resto.html';
                                    }
                                };
    xhttp.open("POST", "http://localhost:8082/signin", true);
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(json);
}

function userJson(userName, userEmail, userPassword) {
	return "{ \"userName\":\"" + userName + "\", \"userEmail\":\"" + userEmail
			+ "\", \"userPassword\":\"" + userPassword + "\"}";
}