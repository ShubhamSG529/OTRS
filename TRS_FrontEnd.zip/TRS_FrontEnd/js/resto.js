function menuList(){
    document.getElementById("main_div").style.display="none";
    document.getElementById("menulist").style.display="inline";
}

function RestoList(){
    document.getElementById("main_div").style.display="inline";
    document.getElementById("menulist").style.display="none";
}

function confirmOrder(){
    document.getElementById("menulist").onclick = function () {
        location.href = "placeOrder.html";
    };
}