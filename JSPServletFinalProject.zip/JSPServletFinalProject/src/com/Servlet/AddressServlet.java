package com.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.daoImpl.AddressDaoImpl;
import com.entity.Address;

/**
 * Servlet implementation class AddressServlet
 */
@WebServlet("/AddressServlet")
public class AddressServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AddressDaoImpl addressDaoImpl=new AddressDaoImpl();
	Address address=new Address();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddressServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			boolean flag=false;  
			if((request.getParameter("StreetName")!="") || (request.getParameter("StreetName")!=" ") || !(request.getParameter("StreetName").trim().equals(" ")) 
					|| !(request.getParameter("StreetName").equals("")) || request.getParameter("StreetName")!=null || !(request.getParameter("City").equals(null)) || !(request.getParameter("City").equals("")) || !(request.getParameter("City").trim().equals(" ")) 
					|| !(request.getParameter("City").equals("")) || request.getParameter("City")!=null || !(request.getParameter("State").equals(null)) || !(request.getParameter("State").equals("")) || !(request.getParameter("State").trim().equals(" ")) 
					|| !(request.getParameter("State").equals("")) || request.getParameter("State")!=null || !(request.getParameter("Pin").equals(null)) || !(request.getParameter("Pin").equals("")) || !(request.getParameter("Pin").trim().equals(" ")) 
					|| !(request.getParameter("Pin").equals("")) || request.getParameter("Pin")!=null){
				String streetName=request.getParameter("StreetName");
				String city=request.getParameter("City");
				String state=request.getParameter("State");
				String Pin=request.getParameter("Pin");
				String sessionNumber=request.getSession(false).toString();
				String SUBsession=request.getSession(false).toString().substring((sessionNumber.length())-4);
				String addressId=streetName.substring(0,1)+Pin+SUBsession;
				address.setAddressId(addressId);
				address.setStreetName(streetName);
				address.setCity(city);
				address.setState(state);
				address.setPin(Integer.parseInt(Pin));
				address.setCustomerId((String)request.getSession(false).getAttribute("CutomerID"));
				flag=addressDaoImpl.addAddress(address);
				//flag=true;
			}
			if(flag)
				response.sendRedirect("PaymentPage.jsp");
			else{
				request.getSession(false).setAttribute("AdressErrorMessage", "2");
				response.sendRedirect("AddressPage.jsp");
			}
		}catch(Exception e){
			request.getSession(false).setAttribute("AdressErrorMessage", "1");
			response.sendRedirect("AddressPage.jsp");
		}
	}

}
