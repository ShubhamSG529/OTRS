package com.Servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.daoImpl.CreditCardDaoImpl;
import com.daoImpl.CustomerDaoImpl;
import com.daoImpl.ProductsCustomerDaoImpl;
import com.entity.Product;

/**
 * Servlet implementation class Payment
 */
@WebServlet("/Payment")
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDaoImpl customerDaoImpl=new CustomerDaoImpl();
		ProductsCustomerDaoImpl productsCustomerDaoImpl=new ProductsCustomerDaoImpl();
		try{
			String Dbpass=null;
			boolean password=false,amount=false,nullFlag=false;;
			String mode=request.getParameter("radio");
			double ammount=(Double)request.getSession(false).getAttribute("Price");
			
			double dbAmmount=0;
			ResultSet resSetDebit=new CustomerDaoImpl().getCustomer((String)request.getSession(false).getAttribute("CutomerID"),(String)request.getSession(false).getAttribute("Password"));
			while(resSetDebit.next())
				dbAmmount=resSetDebit.getDouble("amount");
			double creditAmount=0;
			ResultSet resSet=new CreditCardDaoImpl().getCreditCardAmount((String)request.getSession(false).getAttribute("CutomerID"));
			while(resSet.next())
				creditAmount=resSet.getDouble("amount");
			ResultSet rs=customerDaoImpl.getPassword((String)request.getSession(false).getAttribute("CutomerID"));
			while(rs.next()){
			Dbpass=	rs.getString("password");
				System.out.println("DB:"+Dbpass);
			}
			
			if(mode==null){
				request.getSession(false).setAttribute("PaymentSuccess", "errorRadio");
				response.sendRedirect("PaymentPage.jsp");
				nullFlag=true;
			}else if(mode.equalsIgnoreCase("debitCardInput")){
				String pass=request.getParameter("debitPassword");
				System.out.println(pass);
				if(pass.equalsIgnoreCase(Dbpass)){ 
					password=true;
					if(ammount<dbAmmount){
						dbAmmount=dbAmmount-ammount;
						amount=new CustomerDaoImpl().addCustomerAmount((String)request.getSession(false).getAttribute("CutomerID"), dbAmmount);
						//amount=true;
						
					}
					
				}
				
				
			}else if(mode.equalsIgnoreCase("CreditCardInput")){
				System.out.println("credit");
				String pass=request.getParameter("creditPassword");
				System.out.println(pass);
				
				if(pass.equalsIgnoreCase(Dbpass)){ 
					password=true;
					amount=true;
					creditAmount=creditAmount+ammount;
					new CreditCardDaoImpl().addCreditCardAmount((String)request.getSession(false).getAttribute("CutomerID"),creditAmount);
				}
				
				
			}else if(mode.equalsIgnoreCase("NetBankingInput")){
				System.out.println("netBanking");
				String pass=request.getParameter("netPassword");
				System.out.println(pass);
				
				if(pass.equalsIgnoreCase(Dbpass)){ 
					password=true;
					if(ammount<dbAmmount){
						dbAmmount=dbAmmount-ammount;
						//System.out.println("hiiiiiiiiiiiiii"+dbAmmount);
						amount=new CustomerDaoImpl().addCustomerAmount((String)request.getSession(false).getAttribute("CutomerID"), dbAmmount);					
						
					}
					
				}
				
			}if(!nullFlag){
			if(password && amount){ 
				String cusId=(String)request.getSession(false).getAttribute("CutomerID");
				String dbCardNo=(String)request.getSession(false).getAttribute("DebitCardNumber");
				String creditCard=(String)request.getSession(false).getAttribute("CreditCard");
				for(int i=0;i<Product.list.size();i++){
					productsCustomerDaoImpl.addProduct(Product.list.get(i).getProductId(), cusId, dbCardNo, creditCard, Product.list.get(i).getPrice());
				}
				System.out.println("pass and amt");
				response.sendRedirect("PlaceOrder.jsp");
			}
			else if(password && !amount){
				request.getSession(false).setAttribute("PaymentSuccess", "errorAmmount");
				System.out.println("pass and not amt");
				response.sendRedirect("PaymentPage.jsp");
			}
			else if(!password){
				request.getSession(false).setAttribute("PaymentSuccess", "errorPassword");
				System.out.println("not pass and amt");
				response.sendRedirect("PaymentPage.jsp");
			}else {
				System.out.println("nothing");
				response.sendRedirect("PaymentPage.jsp");
			}
			}
		}catch(Exception e){
			e.printStackTrace();
			request.getSession(false).setAttribute("PaymentSuccess", "error");
			response.sendRedirect("PaymentPage.jsp");
		}
	}
}
