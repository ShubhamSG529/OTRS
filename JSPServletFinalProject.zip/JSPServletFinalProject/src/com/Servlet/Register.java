package com.Servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DBConnection.db_connection;
import com.daoImpl.CustomerDaoImpl;
import com.entity.Customer;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CustomerDaoImpl customerDaoImpl=new CustomerDaoImpl();
	Customer customer =new Customer();
	db_connection db_connection=new db_connection();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username");
		String userId=request.getParameter("userId");
		String accountNumber=request.getParameter("accountNumber");
		String debitCardNumber=request.getParameter("debitCardNumber");
		String password=request.getParameter("pass");
		boolean flag=false,alreadyexsist=false;
		try {
			ResultSet rs=  customerDaoImpl.getaLLCustomerID();
			//ResultSet rs=  customerDaoImpl.getCustomer(userId, password);
			while(rs.next()){  
				if(userId.equalsIgnoreCase(rs.getString("customerId"))){
					flag=true;//System.out.println(rs.getString(1));
					alreadyexsist=true;
					break;
				}
			}
			
			if(username.equalsIgnoreCase("") || username.equalsIgnoreCase(" ") || username.equalsIgnoreCase(null)
					|| password.equalsIgnoreCase("") || password.equalsIgnoreCase(" ") || password.equalsIgnoreCase(null)
					 || userId.equalsIgnoreCase("") || userId.equalsIgnoreCase(" ") || userId.equalsIgnoreCase(null)
					 || accountNumber.equalsIgnoreCase("") || accountNumber.equalsIgnoreCase(" ") || accountNumber.equalsIgnoreCase(null)
					 || debitCardNumber.equalsIgnoreCase("") || debitCardNumber.equalsIgnoreCase(" ") || debitCardNumber.equalsIgnoreCase(null))
				flag=true;
			
			boolean i=false;
			if(!flag){
				customer.setCustomerId(userId);
				customer.setAccountNumber(accountNumber);
				customer.setCustomerName(username);
				customer.setPassword(password);
				customer.setDebitCardNumber(debitCardNumber);
				customer.setAmount(1000000);
				
				i=customerDaoImpl.addCustomer(customer);
				System.out.println(i+" records inserted");
			}else{
				System.out.println("No records inserted");
			}
			  
			  
			//Statement stmt = con.createStatement();
			//System.out.println("Created DB Connection....");
			if(i)
				response.sendRedirect("Form.jsp");
				//request.getRequestDispatcher("Form.jsp").include(request, response);
			else if(alreadyexsist){
				request.getSession(false).setAttribute("RegisterErrorMessage", "Sorry!!UserId already taken!!");
				response.sendRedirect("Register.jsp");
			}
			else{
				//response.sendRedirect("Register.jsp");
				request.getSession(false).setAttribute("RegisterErrorMessage", "Sorry!! Invalid Credentials!!");
				response.sendRedirect("Register.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			//response.sendRedirect("Register.jsp");
			request.getSession(false).setAttribute("RegisterErrorMessage", "Sorry!! Invalid Credentials!!");
			response.sendRedirect("Register.jsp");
		}
		finally{
			db_connection.closeConnection();
		}
	}

}
