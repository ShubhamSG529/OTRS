package com.Servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.daoImpl.CustomerDaoImpl;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try{
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String name=null;
		CustomerDaoImpl customerDaoImpl=new CustomerDaoImpl();
		ResultSet rs=customerDaoImpl.getCustomer(username, password);
		
		boolean flag=false,passflag=false;

		while(rs.next()){  
			if(username.equalsIgnoreCase(rs.getString("customerId")) ){
				//System.out.println(rs.getString("customerId"));
				
				name=rs.getString("customerName");
				if(password.equalsIgnoreCase(rs.getString("password"))){
					flag=true; 
					passflag=true;
				}else{
					flag=true;
				}
				break;
			}
		}
		if(flag && passflag){			
			HttpSession httpSession=request.getSession(true);
			httpSession.setAttribute("CutomerID", username);
			httpSession.setAttribute("Name", name);
			httpSession.setAttribute("Password", password);
			httpSession.setAttribute("DebitCardNumber", rs.getString("debitCardNumber"));
			//httpSession.setAttribute("DebitAmount", rs.getString("amount"));
			httpSession.setAttribute("AccountNumber", rs.getString("accountNumber"));
			response.sendRedirect("HomePage.jsp");
		}
		else if(!passflag || username.equalsIgnoreCase("") 
				|| username.equalsIgnoreCase(" ") || username.equalsIgnoreCase(null) || password.equalsIgnoreCase("") 
				|| password.equalsIgnoreCase(" ") || password.equalsIgnoreCase(null)){
			
			request.getSession(false).setAttribute("LoginErrorMessage", "1");
			response.sendRedirect("Form.jsp");
			
			}
		else
			//request.getRequestDispatcher("Register.jsp").include(request, response);
			response.sendRedirect("Register.jsp");
		}catch(Exception e){
			e.printStackTrace();
			//response.getWriter().print("Hi");
			request.getSession(false).setAttribute("LoginErrorMessage", "1");
			response.sendRedirect("Form.jsp");
			
			//response.sendRedirect("Form.jsp");
		}
	}
}
