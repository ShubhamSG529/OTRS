package com.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBConnection.db_connection;
import com.dao.CreditCardDao;
import com.entity.CreditCard;


public class CreditCardDaoImpl implements CreditCardDao {
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	public boolean addCreditCardAmount(String customerId,double amount) {
		try {
			prepstmt=db_connection.getPrepareStatement("update CreditCard set amount=? where customerId=?");
			prepstmt.setDouble(1, amount);
			prepstmt.setString(2, customerId);
			
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
		
	}
	public ResultSet getCreditCardAmount(String customerId) {
		try {
			prepstmt=db_connection.getPrepareStatement("select amount from CreditCard where customerId=?");
			prepstmt.setString(1, customerId);
			ResultSet creditCardAmount=prepstmt.executeQuery();
			return creditCardAmount;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}	
		
	}
	public ResultSet getCreditCardDetails(String customerId) {
		try {
			prepstmt=db_connection.getPrepareStatement("select * from CreditCard where customerId=?");
			prepstmt.setString(1, customerId);
			ResultSet creditCardDetails=prepstmt.executeQuery();
			return creditCardDetails;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	public ResultSet getCreditCardNumber(String customerId) {
		try {
			prepstmt=db_connection.getPrepareStatement("select creditCardNumber from CreditCard where customerId=?");
			prepstmt.setString(1, customerId);
			ResultSet creditCardDetails=prepstmt.executeQuery();
			return creditCardDetails;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean addCreditCard(CreditCard creditCard) {
		try {
			prepstmt=db_connection.getPrepareStatement("insert into CreditCard values(?,?,?,?,?)");
			prepstmt.setString(1, creditCard.getCreditCardNumber());
			prepstmt.setString(2, creditCard.getAccountNumber());
			prepstmt.setString(3, creditCard.getCustomerId());
			prepstmt.setString(4, creditCard.getPassword());
			prepstmt.setString(5, creditCard.getAmount());
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}
	
}
