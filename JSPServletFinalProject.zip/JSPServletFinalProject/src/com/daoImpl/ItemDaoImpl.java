package com.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBConnection.db_connection;
import com.dao.ItemDao;

public class ItemDaoImpl implements ItemDao {
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	
	public ResultSet getAllItems() {
		try {			
			prepstmt=db_connection.getPrepareStatement("select * from Item");
			ResultSet items=prepstmt.executeQuery();
			return items;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public ResultSet getItem(String itemId) {
		try {			
			prepstmt=db_connection.getPrepareStatement("select * from Item where itemId=?");
			prepstmt.setString(1, itemId);
			ResultSet item=prepstmt.executeQuery();
			return item;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public boolean updateItemName(String itemId,String itemName) {
		try {
			prepstmt=db_connection.getPrepareStatement("update Item set itemName=? where itemId=?");
			prepstmt.setString(1, itemName);
			prepstmt.setString(2, itemId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deleteItem(String itemId) {
		try {
			prepstmt=db_connection.getPrepareStatement("delete Item where itemId=?");
			prepstmt.setString(1, itemId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
