package com.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.DBConnection.db_connection;
import com.dao.CustomerDao;
import com.entity.Customer;

public class CustomerDaoImpl implements CustomerDao{
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	Statement stmt=null;
	
	public ResultSet getCustomer(String customerId,String password) {
		try {
			prepstmt=db_connection.getPrepareStatement("select * from Customer where customerId=? and password=?");
			prepstmt.setString(1, customerId);
			prepstmt.setString(2, password);
			ResultSet customerDetails=prepstmt.executeQuery();
			return customerDetails;
		} catch (SQLException e) {
			//e.printStackTrace();
			return null;
		}
	}
	public ResultSet getPassword(String customerId) {
		try {
			prepstmt=db_connection.getPrepareStatement("select password from Customer where customerId=?");
			prepstmt.setString(1, customerId);
			ResultSet customerDetails=prepstmt.executeQuery();
			return customerDetails;
		} catch (SQLException e) {
			//e.printStackTrace();
			return null;
		}
	}
	public ResultSet getaLLCustomerID() {
		try {
			prepstmt=db_connection.getPrepareStatement("select customerId from Customer");
			ResultSet customerDetails=prepstmt.executeQuery();
			return customerDetails;
		} catch (SQLException e) {
			//e.printStackTrace();
			return null;
		}
	}

	public boolean addCustomer(Customer cutomer) {
		try {
			prepstmt=db_connection.getPrepareStatement("insert into Customer values(?,?,?,?,?,?)");
			prepstmt.setString(1, cutomer.getCustomerId());
			prepstmt.setString(2, cutomer.getAccountNumber());
			prepstmt.setString(3, cutomer.getCustomerName());
			prepstmt.setString(4, cutomer.getPassword());
			prepstmt.setString(5, cutomer.getDebitCardNumber());
			prepstmt.setDouble(6, cutomer.getAmount());
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean addCustomerAmount(String customerId,double amount) {
		try {
			prepstmt=db_connection.getPrepareStatement("update Customer set amount=? where customerId=?");
			prepstmt.setDouble(1, amount);
			prepstmt.setString(2, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			//e.printStackTrace();
			return false;
		}
	}

}
