package com.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBConnection.db_connection;
import com.dao.ProductDao;

public class ProductDaoImpl implements ProductDao {
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	public ResultSet getAllProduct() {
		try {			
			prepstmt=db_connection.getPrepareStatement("select * from Product");
			ResultSet product=prepstmt.executeQuery();
			return product;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public ResultSet getProductDetails(String itemId) {
		try {			
			prepstmt=db_connection.getPrepareStatement("select * from Product where itemId=?");
			prepstmt.setString(1, itemId);
			ResultSet productDetails=prepstmt.executeQuery();
			return productDetails;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
