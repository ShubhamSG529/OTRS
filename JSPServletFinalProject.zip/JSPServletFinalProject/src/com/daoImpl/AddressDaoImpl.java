package com.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBConnection.db_connection;
import com.dao.AddressDao;
import com.entity.Address;

public class AddressDaoImpl implements AddressDao {
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	public ResultSet getAddress(String customerId) {
		try {
			prepstmt=db_connection.getPrepareStatement("select * from Adress where customerId=?");
			prepstmt.setString(1, customerId);
			ResultSet address=prepstmt.executeQuery();
			return address;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}


	public boolean addAddress(Address addAddr) {
		try {
			prepstmt=db_connection.getPrepareStatement("insert into address values(?,?,?,?,?,?)");
			prepstmt.setString(1, addAddr.getAddressId());
			prepstmt.setString(2, addAddr.getStreetName());
			prepstmt.setString(3, addAddr.getCity());
			prepstmt.setString(4, addAddr.getState());
			prepstmt.setInt(5, addAddr.getPin());
			prepstmt.setString(6, addAddr.getCustomerId());
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}		
	}

	public boolean updateStreetName(String customerId, String streetName) {
		try {
			prepstmt=db_connection.getPrepareStatement("update address set streetName=? where customerId=?");
			prepstmt.setString(1, streetName);
			prepstmt.setString(2, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}
	public boolean updateCity(String customerId, String city) {
		try {
			prepstmt=db_connection.getPrepareStatement("update address set city=? where customerId=?");
			prepstmt.setString(1, city);
			prepstmt.setString(2, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}
	public boolean updateState(String customerId, String state) {
		try {
			prepstmt=db_connection.getPrepareStatement("update address set state=? where customerId=?");
			prepstmt.setString(1, state);
			prepstmt.setString(2, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}
	public boolean updatePin(String customerId, String pin) {
		try {
			prepstmt=db_connection.getPrepareStatement("update address set pin=? where customerId=?");
			prepstmt.setString(1, pin);
			prepstmt.setString(2, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}

	
	public boolean deleteAddress(String customerId) {		
		try {
			prepstmt=db_connection.getPrepareStatement("delete address where customerId=?");
			prepstmt.setString(1, customerId);
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}


}
