package com.daoImpl;

import java.sql.PreparedStatement;

import com.DBConnection.db_connection;
import com.dao.ProductsCustomerDao;

public class ProductsCustomerDaoImpl implements ProductsCustomerDao {
	db_connection db_connection=new db_connection();
	PreparedStatement prepstmt=null;
	public boolean addProduct(String productId,String customerId,String debitCardNumber,String creditCardNumber,String price) {		
		try {
			prepstmt=db_connection.getPrepareStatement("insert into productscustomer values(?,?,?,?,?)");
			prepstmt.setString(1, productId);
			prepstmt.setString(2, customerId);
			prepstmt.setString(3, debitCardNumber);
			prepstmt.setString(4, creditCardNumber);
			prepstmt.setString(5, price);
			
			int i=prepstmt.executeUpdate();
			if(i>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}		
		
	}

}
