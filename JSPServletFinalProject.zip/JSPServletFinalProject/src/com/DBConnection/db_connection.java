package com.DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class db_connection {

	String url = "jdbc:mysql://localhost:3306/online_shoppingsite?";
	String username = "root";
	String password = "root";
	Connection con=null;
	PreparedStatement prepstmt=null;
	Statement stmt=null;
	private Connection getConnection()
	{	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url+"user="+username+"&password="+password);
		} catch (Exception e) {			
			e.printStackTrace();
		}
	return con;
	}
	public void closeConnection(){
		try {
			getConnection().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Statement getStatement(){
		
		try {
			stmt=getConnection().createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stmt;
	}
	public PreparedStatement getPrepareStatement(String query){
		
		try {
			prepstmt=getConnection().prepareStatement(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return prepstmt;
	}
	
}
