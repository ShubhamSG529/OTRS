package com.entity;

public class Customer {
private String customerId;
private String accountNumber;
private String customerName;
private String password;
private String debitCardNumber;
private double amount;
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getDebitCardNumber() {
	return debitCardNumber;
}
public void setDebitCardNumber(String debitCardNumber) {
	this.debitCardNumber = debitCardNumber;
}
}
