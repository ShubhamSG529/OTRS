package com.entity;

public class ProductsCustomers {
private String productId;
private String customerId;
private String debitCardNumber;
private String creditCardNumber;
private String price;
public String getProductId() {
	return productId;
}
public void setProductId(String productId) {
	this.productId = productId;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getDebitCardNumber() {
	return debitCardNumber;
}
public void setDebitCardNumber(String debitCardNumber) {
	this.debitCardNumber = debitCardNumber;
}
public String getCreditCardNumber() {
	return creditCardNumber;
}
public void setCreditCardNumber(String creditCardNumber) {
	this.creditCardNumber = creditCardNumber;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}

}
