package com.dao;

import java.sql.ResultSet;

import com.entity.Address;

public interface AddressDao {
public ResultSet getAddress(String customerId);
public boolean addAddress(Address addAddr);
public boolean updateCity(String customerId,String city);
public boolean updateState(String customerId,String state);
public boolean updatePin(String customerId,String pin);
public boolean updateStreetName(String customerId,String streetName);
public boolean deleteAddress(String customerId);
}
