package com.dao;

import java.sql.ResultSet;

import com.entity.CreditCard;

public interface CreditCardDao {
	public ResultSet getCreditCardDetails(String customerId);
	public boolean addCreditCard(CreditCard creditCard);
	public ResultSet getCreditCardNumber(String customerId);
	public boolean addCreditCardAmount(String customerId,double amount);
	public ResultSet getCreditCardAmount(String customerId);
}
