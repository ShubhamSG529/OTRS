package com.dao;

import java.sql.ResultSet;


public interface ProductDao {
public ResultSet getAllProduct();
public ResultSet getProductDetails(String productId);
}
