package com.dao;

import java.sql.ResultSet;


public interface ItemDao {
public ResultSet getAllItems();
public ResultSet getItem(String itemId);
public boolean updateItemName(String itemId,String itemName);
public boolean deleteItem(String itemId);
}
