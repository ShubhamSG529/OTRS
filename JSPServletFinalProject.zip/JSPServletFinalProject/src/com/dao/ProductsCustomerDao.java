package com.dao;

public interface ProductsCustomerDao {
public boolean addProduct(String productId,String customerId,String debitCardNumber,String creditCardNumber,String price);
}
