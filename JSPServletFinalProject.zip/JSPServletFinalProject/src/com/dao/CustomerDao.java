package com.dao;

import java.sql.ResultSet;

import com.entity.Customer;

public interface CustomerDao { 
public ResultSet getCustomer(String customerId,String password);
public boolean addCustomer(Customer cutomer);
public ResultSet getaLLCustomerID();
public ResultSet getPassword(String customerId);
public boolean addCustomerAmount(String customerId,double amount);
/*public boolean updateCustomer(String customerId,Customer cutomer);
public boolean deleteCustomer(String customerId);*/
}
