window.onload = initAll;

var myMap = new Map();
var userId = 0;
var userEmail = "";
var restaurantId = 0;
var accessToken = "";
function initAll(){
    handleCookie();
    if(accessToken=="" || userId == 0){
		alert("Please SignIn for Use of the services");
		window.location = "index.html";
	}
    getAllItems();
    /*var myMap = new Map();
    myMap.set(101,"1");
    myMap.set(102,"2");
    var iterator = myMap.keys();    
    for(var i = 0;i<myMap.size;i++){
        var key = iterator.next().value;
        var value = myMap.get(key);
        alert(value);
    }*/
}
function getAllItems(){
    var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = afterGettingItemList;
	xhttp.open("GET", "http://localhost:7073/restaurant/"+restaurantId+"/items", true);
	xhttp.send();
}
function afterGettingItemList(){
    if(this.readyState == 4 && this.status == 202){
        var response = this.responseText;
        //alert(response);
        var table = document.getElementById("item_table");

        var parsed = JSON.parse(response);
        for(i=0;i<parsed.length;i++){
            var itemId = parsed[i].itemId;
            var itemName = parsed[i].itemName;
            var price = parsed[i].price;
            var tr = "<tr class='listing_row'>"+
                        "<td>"+itemName+"</td>"+
                        "<td>"+price+"</td>"+
                        "<td><select class='qnty' id='"+itemId+"' onchange='selectedElement(this.id)'>"+
                                "<option value='0'>0</option>"+
                                "<option value='1'>1</option>"+
                                "<option value='2'>2</option>"+
                                "<option value='3'>3</option>"+
                            "</select>"+
                        "</td>"+
                        "</tr>";
            myMap.set(itemId+"","0");
            table.innerHTML = table.innerHTML+tr;
        }
        var button = "<br><tr class='place_order'>"+
                        "<td colspan='3'>"+
                            "<button id='place_order' onclick='placeOrder()'>Place Order</button>"+
                        "</td>"+
                     "<tr>";
        table.innerHTML = table.innerHTML+button;
    }
    
}
function placeOrder(){
    var iterator = myMap.keys();
    var item_details = "";
    for(var i = 0;i<myMap.size;i++){
        var itemIdkey = iterator.next().value;
        var quantityValue = myMap.get(itemIdkey);
        item_details = item_details+itemIdkey+"-"+quantityValue+"=";
        //alert("itemId: "+itemIdkey+"- ItemQuantity: "+quantityValue+"- restaurantId: "+restaurantId);
    }
    //alert(item_details);
    var tableNo = window.location.toString().split("?")[1].split("=")[1];
    if(restaurantId != 0 && tableNo != 0 && userId != 0){
        //alert(accessToken);
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = orderPlaced;
        xhttp.open("GET", "http://localhost:7071/place_order/"+restaurantId+"/"+tableNo+"/"+item_details+"/"+userId+"?access_token="+accessToken, true);
        xhttp.send();
    }    
}
function orderPlaced(){
    if(this.readyState == 4 && this.status == 202){
        var response = this.responseText;
        alert(response);
        window.location = "total_bill.html";
        
    }else if(this.readyState == 4 && this.status == 404){
        var response = this.responseText;
        alert(response);
    }if(this.readyState == 4 && this.status == 401){
        alert("Please SignUp/SignIn for completion of your order");
        window.location = "index.html";
    }
}
function selectedElement(id){
    var value = document.getElementById(id).value;
    myMap.set(id+"",value);
}

function handleCookie(){
	var cookies = document.cookie;
	//alert(cookies);
	var objectArray = cookies.split(";");
	for(var i=0;i<objectArray.length;i++){
		var object = objectArray[i].split("=");
		var s = object[0];
        s = s.trim();
        //alert(s);
		if(s=="restaurant_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="restId"){
                    restaurantId = o[k+1];
                    //alert(restaurantId);
				}
			}
		}else if(s=="user_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="userName"){
					document.getElementById("hello_user").innerHTML = "Hi "+o[k+1]+" !!";
				}else if(o[k]=="userId"){
                    userId = o[k+1];
                }else if(o[k]=="userEmail"){
                    userEmail = o[k+1];
                }
			}
		}else if(s=="access_token"){
            accessToken = object[1];
		}
	}
}

function getObjectInArrayForm(object){
	var userObject = new Array();
	var index = 0;
	var str = "";
	for(var i=0;i<object.length;i++){
		var ch = object.charAt(i);
		if(ch=='[' || ch==']' || ch=='{' || ch=='\"'){

		}else if(ch==',' || ch==':' || ch=='}'){
			userObject[index++] = str;
			str = "";
		}else{
			str = str+object[i];
		}
	}
	return userObject;
}
function logout(){
	document.cookie = "user_object=;restaurant_object=;access_token=;";
	document.cookie = "restaurant_object=;";
	document.cookie = "access_token=;";
}