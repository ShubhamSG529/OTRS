window.onload = initAll;
var userJsonObject;

function initAll() {
	formActions('user_name');
	formActions('user_email');
	formActions('user_password');
	formActions('user_repeat_password');

	var userContactElemet = document.getElementById('user_contact');
	/*
	 * userContactElemet.onblur = function(){
	 * if(userContactElemet.value.search('^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$')){
	 * alert('matched'); }else{ alert('not match'); } };
	 */
}

var userEmail;
var userPassword;
function signUpAction() {
	var userName = document.getElementById('user_name').value;
	userEmail = document.getElementById('user_email').value;
	var userContact = document.getElementById('user_contact').value;
	userPassword = document.getElementById('user_password').value;
	var userRepeatPassword = document.getElementById('user_repeat_password').value;

	var flag = 0;
	if (userName == '' || userEmail == '' || userContact == ''
			|| userPassword == '') {
		alert('Please Enter in required field');
		flag = 1;
	}

	var userJsonObject = userJson(userName, userEmail, userContact,
			userPassword);
	if (userPassword != '' && flag == 0) {
		if (userPassword == userRepeatPassword) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = afterSignup;
			xhttp.open("POST", "http://localhost:7072/signup", true);
			xhttp.setRequestHeader('Content-Type', 'application/json');
			xhttp.send(userJsonObject);
		} else {
			alert("Mismatch Passwords");
		}
	} else {
		alert('Enter valid inputs');
	}
}

function afterSignup() {
	if (this.readyState == 4 && this.status == 202) {
		var response = this.responseText;
		//alert(response);
		setUserObjectCookies(response);

		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function(){
									//alert(this.status);
									if (this.readyState == 4 && (this.status == 202 || this.status == 200) ) {
										var response = this.responseText;
										var parsed = JSON.parse(response);
        								var accessToken = parsed.access_token;
										
										document.cookie = "access_token=" + accessToken + ";";
										window.location = 'booking.html';
									}
									};
		xhttp.open("POST", "http://localhost:8082/oauth/token?grant_type=password&username="+userEmail+"&password="+userPassword, true);
		xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xhttp.setRequestHeader("Authorization", "Basic " + btoa("my-trusted-client:secret"));
		xhttp.send();
		
		
	}
}


function loggedIn() {
	var userEmail = document.getElementById('login_user_email').value;
	var userPassword = document.getElementById('login_user_password').value;

	userJsonObject = userJson("", userEmail, "", userPassword);
	if (userEmail != "" && userPassword != "") {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = afterLogin;
		xhttp.open("POST", "http://localhost:8082/oauth/token?grant_type=password&username="+userEmail+"&password="+userPassword, true);
		xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xhttp.setRequestHeader("Authorization", "Basic " + btoa("my-trusted-client:secret"));
		xhttp.send();

		/*var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = afterLogin;
		xhttp.open("POST", "http://localhost:7070/login", true);
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(userJsonObject);*/
	}
}
function afterLogin() {
	if (this.readyState == 4 && (this.status == 202 || this.status == 200)) {
		var response = this.responseText;
		
		var parsed = JSON.parse(response);
        var accessToken = parsed.access_token;
        var tokenType = parsed.token_type;
		
		document.cookie = "access_token=" + accessToken + ";";

		//alert("afterLogin: "+userJsonObject);
		var xhttp2 = new XMLHttpRequest();
		xhttp2.onreadystatechange = function(){
										//alert(this.status);
										if (this.readyState == 4 && (this.status == 202 || this.status == 200)) {
											var response = this.responseText;
											//alert(response);
											console.log(document.cookie);
											setUserObjectCookies(response);
											window.location = 'booking.html';
										}
									};
		xhttp2.open("POST", "http://localhost:7072/login", true);
		xhttp2.setRequestHeader('Content-Type', 'application/json');
		xhttp2.send(userJsonObject);

		//setUserObjectCookies(response);
		//window.location = 'booking.html';
	}if(this.readyState == 4 && this.status == 406){
		var response = this.responseText;
		alert(response);
	}
}
/*function loginUser(){
	//alert("login :"+this.status);
	if (this.readyState == 4 && (this.status == 202 || this.status == 200)) {
		var response = this.responseText;
		//alert(response);
		setUserObjectCookies(response);
		console.log(document.cookie);
	}
}*/

function setUserObjectCookies(response){
	document.cookie = "user_object=" + response + ";";
}

function userJson(userName, userEmail, userContact, userPassword) {
	return "{ \"userName\":\"" + userName + "\", \"userEmail\":\"" + userEmail
			+ "\", \"userContact\":\"" + userContact
			+ "\", \"userPassword\":\"" + userPassword + "\"}";
}

function formActions(id) {
	var field = document.getElementById(id);
	var value = field.placeholder;
	field.onfocus = function() {
		field.className = 'shadow_border';
		field.removeAttribute('placeholder');
	};
	field.onblur = function() {
		field.style.borderBottom = '1px solid black';
		field.className = '';
		field.placeholder = value;
	};
}
function loginPageForward() {
	var form = document.getElementById('form');
	form.style.display = 'none';

	var loginForm = document.getElementById('login_form');
	loginForm.style.display = 'inline';
}
function SignUpPageForward() {
	var loginForm = document.getElementById('login_form');
	loginForm.style.display = 'none';

	var form = document.getElementById('form');
	form.style.display = 'inline';
}