window.onload = initAll;

var userId;
var userEmail;
var accessToken;
function initAll(){
    handleCookie();
    if(accessToken==""){
		alert("Please SignIn for Use of the services");
		window.location = "index.html";
	}
    //alert("userId :"+userId);
    //alert(accessToken);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = generateBill;
    xhttp.open("GET", "http://localhost:7073/order/generate_bill/"+userId+"?access_token="+accessToken, true);
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send();
}

function generateBill(){
    if (this.readyState == 4 && this.status == 202) {
		var response = this.responseText;		
		//alert(response);		
		var billDiv = document.getElementById("bill");
        
        var parsed = JSON.parse(response);
        var userName = parsed.userName;
        var restName = parsed.restName;
        var restAddress = parsed.restAddress;
        var orderDate = parsed.orderDate;
        var orderTime = parsed.orderTime;
        var tableNo = parsed.tableNo;
        var itemdto = parsed.itemdto;
        var totalAmount = parsed.totalAmount;

        var str1 = "<div id='rest_name'>"+restName+"</div><div id='address'><address>"+
        restAddress+"</address></div>"+
        "<table id='info'><tr><td>Name: "+userName+"</td><td>Date: "+orderDate+"</td>"+
        "</tr><tr><td>Table: "+tableNo+"</td><td>Time: "+orderTime+"</td></tr></table><hr>";
        billDiv.innerHTML = billDiv.innerHTML+ str1;
        var str2 = "<table id='item_info'>";
        for(var i=0;i<itemdto.length;i++){
            var itemId = itemdto[i].itemId;
            var itemName = itemdto[i].itemName;
            var itemQuantity = itemdto[i].itemQuantity;
            var itemPrice = itemdto[i].itemPrice;
            str2 = str2+"<tr><td width='15%' class='item_id'>"+(i+1)+"</td><td width='60%'>"+itemName+"</td>"+
                    "<td width='15%'>"+itemQuantity+"</td><td width='15%'>"+itemPrice+"</td></tr>";
        }        
        str2 = str2+"</table><hr><div><span id='net_ammount'>Net Amount: </span><span id='total_ammount'>"+totalAmount+"</span></div>";
		billDiv.innerHTML = billDiv.innerHTML+ str2;
		
		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
                                        if(this.readyState == 4 && this.status == 202){
											var response = this.responseText;
                                            console.log(response);
                                        }                                    
                                    };
        xhttp.open("GET", "http://localhost:7074/send_email/"+userEmail, true);
        xhttp.send();
    }
    if (this.readyState == 4 && this.status == 401) {
        //alert("Authorization error");
    }
}

function handleCookie(){
	var cookies = document.cookie;
	//alert(cookies);
	var objectArray = cookies.split(";");
	for(var i=0;i<objectArray.length;i++){
		var object = objectArray[i].split("=");
		var s = object[0];
		s = s.trim();
		if(s=="restaurant_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="restaurantId"){
					//restaurantId = o[k+1];
				}
			}
		}else if(s=="user_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="userName"){
					document.getElementById("hello_user").innerHTML = "Hi "+o[k+1]+" !!";
				}else if(o[k]=="userId"){
                    userId = o[k+1];
                }else if(o[k]=="userEmail"){
                    userEmail = o[k+1];
                }
			}
		}else if(s=="access_token"){
			accessToken = object[1];
		}
	}
}

function getObjectInArrayForm(object){
	var userObject = new Array();
	var index = 0;
	var str = "";
	for(var i=0;i<object.length;i++){
		var ch = object.charAt(i);
		if(ch=='[' || ch==']' || ch=='{' || ch=='\"'){

		}else if(ch==',' || ch==':' || ch=='}'){
			userObject[index++] = str;
			str = "";
		}else{
			str = str+object[i];
		}
	}
	return userObject;
}
function logout(){
	document.cookie = "user_object=;restaurant_object=;access_token=;";
	document.cookie = "restaurant_object=;";
	document.cookie = "access_token=;";
}