window.onload = initAll;

var accessToken = "";
var userEmail = "";
function initAll(){
	handleCookie();
	//console.log("accessToken>"+accessToken+"<");
	console.log("UserEmail>"+userEmail+"<");
	if(accessToken.trim() == "" && userEmail.trim() == ""){
		alert("Please SignIn for Use of the services");
		window.location = "index.html";
	}
	handleRestaurantsShow();
}

function handleRestaurantsShow(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = showRestaurants;
	xhttp.open("GET", "http://localhost:7073/restaurants", true);
	xhttp.send();
}

function showRestaurants(){
	if (this.readyState == 4 && this.status == 202) {
		var response = this.responseText;
		var restArray = getObjectInArrayForm(response);

		var mainDiv = document.getElementById("mainDiv");
		var str = "";
		var id = 0;
		var restName = "";
		var count = 0;
		for(var i = 0 ; i < restArray.length ; i++){
			if(restArray[i]=="restId"){
				id = restArray[i+1];
				count++;
			}
			if(restArray[i]=="restName"){
				restName = restArray[i+1];				
				count++;
			}
			if(count==2){
				var restShow = "<div class='responsive'>"+
							"<div class='gallery'>"+
								"<img id='"+id+"' onClick='clicked(this.id)' src='images/restaurant"+id+".jpg' width='300' height='200'>"+
								"<div>"+restName+"</div>"+
							"</div>"+
						"</div>";
				str = str + restShow;
				mainDiv.innerHTML = str;
				count = 0;
			}
		}	

	}if(this.readyState == 4 && this.status == 406){
		alert("There are no Restaurant entry in DB");
	}
}

function clicked(id){
	window.location = "book_table.html?restaurant_id="+id;
}

function handleCookie(){
	var cookies = document.cookie;
	//alert(cookies);
	var objectArray = cookies.split(";");
	for(var i=0;i<objectArray.length;i++){
		var object = objectArray[i].split("=");
		var s = object[0];
		s = s.trim();
		if(s=="restaurant_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="restName"){
					//alert(o[k+1]);
				}
			}
		}else if(s=="user_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="userName"){
					document.getElementById("hello_user").innerHTML = "Hi "+o[k+1]+" !!";
				}else if(o[k]=="userEmail"){
					userEmail = o[k+1];
				}
			}
		}else if(s=="access_token"){
			accessToken = object[1];
		}
	}
}

function getObjectInArrayForm(object){
	var userObject = new Array();
	var index = 0;
	var str = "";
	for(var i=0;i<object.length;i++){
		var ch = object.charAt(i);
		if(ch=='[' || ch==']' || ch=='{' || ch=='\"'){

		}else if(ch==',' || ch==':' || ch=='}'){
			userObject[index++] = str;
			str = "";
		}else{
			str = str+object[i];
		}
	}
	return userObject;
}
function logout(){
	document.cookie = "user_object=;restaurant_object=;access_token=;";
	document.cookie = "restaurant_object=;";
	document.cookie = "access_token=;";
}