window.onload = initAll;

var restaurantId;
var accessToken = "";
function initAll(){
	handleCookie();
	if(accessToken==""){
		alert("Please SignIn for Use of the services");
		window.location = "index.html";
	}

	var array = window.location+"".split("=");
	var id = array[array.length-1];

	var location = window.location+"";
	restaurantId = location.split("?")[1].split("=")[1];

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = afterGettingRestaurant;
	xhttp.open("GET", "http://localhost:7073/restaurant/"+restaurantId, true);
	xhttp.send();
}
function afterGettingRestaurant(){
	if (this.readyState == 4 && this.status == 202) {
		var response = this.responseText;
		document.cookie = "restaurant_object=" + response + ";";
		var restObjectArray = getObjectInArrayForm(response);
		for(var i=0;i<restObjectArray.length;i++){
			if(restObjectArray[i]=="restName"){
				var restName = document.getElementById("rest_name");
				restName.innerHTML = restObjectArray[i+1];
			}
			if(restObjectArray[i]=="restId"){
				var id = restObjectArray[i+1];
				var imgSpan = document.getElementById("restImg");
				var imgTag = "<img id='"+id+"' class='rest_img' src='images/restaurant"+id+".jpg' width='400' height='200'>";
				imgSpan.innerHTML = imgTag;
			}
		}
		
		
		console.log(response);
	}if(this.readyState == 4 && this.status == 406){
		alert("There are no restaurant present with this id");
	}
}

function selectedTable(tableId){
	//alert(tableId+" -- "+restaurantId);
	window.location = "item_listing.html?table_no="+tableId;
}

function handleCookie(){
	var cookies = document.cookie;
	//alert(cookies);
	var objectArray = cookies.split(";");
	for(var i=0;i<objectArray.length;i++){
		var object = objectArray[i].split("=");
		var s = object[0];
		s = s.trim();
		if(s=="restaurant_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="restName"){
					//alert(o[k+1]);
				}
			}
		}else if(s=="user_object"){
			var o = getObjectInArrayForm(object[1]);
			for(var k=0;k<o.length-1;k++){
				if(o[k]=="userName"){
					document.getElementById("hello_user").innerHTML = "Hi "+o[k+1]+" !!";
				}
			}
		}else if(s=="access_token"){
			accessToken = object[1];
		}
	}
}

function getObjectInArrayForm(object){
	var userObject = new Array();
	var index = 0;
	var str = "";
	for(var i=0;i<object.length;i++){
		var ch = object.charAt(i);
		if(ch=='[' || ch==']' || ch=='{' || ch=='\"'){

		}else if(ch==',' || ch==':' || ch=='}'){
			userObject[index++] = str;
			str = "";
		}else{
			str = str+object[i];
		}
	}
	return userObject;
}

function logout(){
	document.cookie = "user_object=;restaurant_object=;access_token=;";
	document.cookie = "restaurant_object=;";
	document.cookie = "access_token=;";
}