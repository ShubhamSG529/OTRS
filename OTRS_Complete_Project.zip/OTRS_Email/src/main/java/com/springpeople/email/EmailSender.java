package com.springpeople.email;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.MessagingException;

public class EmailSender {
	public static boolean send(String toEmail) {
		boolean flag = false;

		Properties p = new Properties();

		p.put("mail.transport.protocol", "smtp");
		p.put("mail.smtp.auth", "true");
		p.put("mail.smtp.starttls.enable", "true");
		p.put("mail.smtp.host", "smtp.gmail.com");
		p.put("mail.smtp.port", "587");// 465-587

		Session session = Session.getInstance(p, new EmailAuthenticator());

		MimeMessage msg = new MimeMessage(session);

		try {
			msg.setFrom(new InternetAddress("pqr193600@gmail.com"));
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
			msg.setSubject("Subject");
			msg.setContent("Booking Confirmed", "text/html");
			Transport.send(msg);
			flag = true;
		} catch (AddressException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return flag;
	}
}