package com.springpeople.service;

import org.springframework.stereotype.Service;

import com.springpeople.email.EmailSender;

@Service
public class EmailServiceImpl implements EmailService{

	@Override
	public boolean sendEmail(String userEmail) {
		boolean send = EmailSender.send(userEmail);
		return send;		
	}

}
