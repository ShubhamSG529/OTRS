package com.springpeople.service;

public interface EmailService {

	boolean sendEmail(String userEmail);
}
