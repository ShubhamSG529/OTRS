package com.springpeople.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.service.EmailService;

@RestController
@CrossOrigin
public class EmailController {

	@Autowired
	EmailService emailService;

	@RequestMapping(value = "/send_email/{user_email}")
	public ResponseEntity<String> bookingConfirmEmail(@PathVariable(name = "user_email") String userEmail) {
		System.out.println("EmailController-bookingConfirmEmail");
		boolean flag = emailService.sendEmail(userEmail);
		if (flag) {
			return new ResponseEntity<String>(
					"Booking Confirmation Email Send to your Registered Email " + userEmail + " !!",
					HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);// #404
		}

	}

	@RequestMapping(value = "/public")
	public ResponseEntity<String> publicData() {
		System.out.println("UserController-publicData");
		return new ResponseEntity<String>("public !!", HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/private")
	public ResponseEntity<String> privateData() {
		System.out.println("UserController-privateData");
		return new ResponseEntity<String>("private !!", HttpStatus.ACCEPTED);
	}
}
