package com.springpeople.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.entity.User;
import com.springpeople.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/user/{email}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> getUser(@PathVariable(name = "email") String email) {
		System.out.println("UserController-getUser");
		User user = userService.getUserByEmail(email + ".com");
		if (user != null)
			return new ResponseEntity<User>(user, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(user, HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getUsers() {
		System.out.println("UserController-getUsers");
		List<User> allUsers = userService.getAllUsers();
		if (allUsers.size() == 0) {
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<User>>(allUsers, HttpStatus.ACCEPTED);
		}
	}

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public ResponseEntity<String> hello() {
		System.out.println("UserController-hello");
		return new ResponseEntity<String>("Hello World !!!", HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/demo", method = RequestMethod.GET)
	public ResponseEntity<String> demo() {
		System.out.println("UserController-demo");
		return new ResponseEntity<String>("Demo !!!", HttpStatus.ACCEPTED);
	}
}
