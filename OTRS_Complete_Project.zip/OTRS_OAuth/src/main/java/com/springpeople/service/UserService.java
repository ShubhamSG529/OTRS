package com.springpeople.service;

import java.util.List;
import java.util.Optional;

import com.springpeople.entity.User;

public interface UserService {

	public User addUser(User user);

	public User getUserByEmail(String email);

	public Optional<User> isExist(String email);

	public List<User> getAllUsers();

}
