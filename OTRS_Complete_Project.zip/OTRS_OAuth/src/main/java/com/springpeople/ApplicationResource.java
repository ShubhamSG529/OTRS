package com.springpeople;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class ApplicationResource {

	@CrossOrigin
	@RequestMapping("/user")
	public Principal user(Principal user) {
		System.out.println("ApplicationResource User Principal :" + user);
		return user;
	}

	@CrossOrigin
	@PreAuthorize("hasAnyRole('ADMIN')")
	@GetMapping
	public String hello() {
		System.out.println("ApplicationResource_Hello");
		return "Hello World!!";
	}

}
