package com.springpeople.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;

import com.springpeople.service.CustomUserDetailsService;

@EnableResourceServer
@Configuration
public class ResourceServerConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private CustomUserDetailsService userDetailsService;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("ResourceServerConfig-configure-HttpSecurity");
		http.csrf().disable().authorizeRequests().antMatchers("/hello", "/users/**").permitAll().anyRequest()
				.authenticated().and().exceptionHandling().accessDeniedHandler(new OAuth2AccessDeniedHandler()).and()
				.httpBasic().disable();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println("ResourceServerConfig-configure-AuthenticationManagerBuilder");
		auth.userDetailsService(userDetailsService);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		System.out.println("ResourceServerConfig-configure-WebSecurity");
		web.ignoring().antMatchers(HttpMethod.POST, "/signup").antMatchers(HttpMethod.GET, "/rest/user", "/hello")
				.antMatchers("oauth/authorize", "oauth/token");

	}
}
