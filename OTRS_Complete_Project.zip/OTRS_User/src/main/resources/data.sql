INSERT INTO role(role) VALUES('ADMIN'),('USER');
INSERT INTO USER(active, email,contact, NAME, PASSWORD) VALUES(1, 'shubhamsg@gmail.com','8964005911', 'ShubhamSG', 'admin');
INSERT INTO USER(active, email,contact, NAME, PASSWORD) VALUES(2, 'user@gmail.com','9876543210', 'user', 'user');
INSERT INTO user_roles (user_user_id,roles_role_id) VALUES(1,1),(2,2);
