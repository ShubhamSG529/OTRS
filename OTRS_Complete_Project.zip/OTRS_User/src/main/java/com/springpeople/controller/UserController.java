package com.springpeople.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.entity.User;
import com.springpeople.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/signup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> addUser(@RequestBody User user) {
		System.out.println("UserController-addUser");
		User addedUser = userService.insertUser(user);
		if (addedUser != null)
			return new ResponseEntity<User>(addedUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.CONFLICT);
	}

	@RequestMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getUsers() {
		System.out.println("UserController-getUsers");
		List<User> allUser = userService.getAllUser();
		if (allUser.size() != 0)
			return new ResponseEntity<List<User>>(allUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		System.out.println("UserController-loginUsers ");
		User getUser = userService.getUser(user);
		if (getUser != null)
			return new ResponseEntity<User>(getUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value = "/user/{user_id}" , produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> getUser(@PathVariable("user_id") int userId) {
		System.out.println("UserController-getUser ");
		User getUser = userService.getUserById(userId);
		System.out.println("getUser: "+getUser);
		if (getUser != null)
			return new ResponseEntity<User>(getUser, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/public")
	public ResponseEntity<String> publicData() {
		System.out.println("UserController-publicData");
		return new ResponseEntity<String>("public !!", HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/private")
	public ResponseEntity<String> privateData() {
		System.out.println("UserController-privateData");
		return new ResponseEntity<String>("private !!", HttpStatus.ACCEPTED);
	}
}
