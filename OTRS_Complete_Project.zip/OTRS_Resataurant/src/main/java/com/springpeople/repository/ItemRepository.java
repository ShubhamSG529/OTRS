package com.springpeople.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springpeople.entity.Item;

@Repository
@Transactional
public interface ItemRepository extends JpaRepository<Item, Integer>{
	
	//@Query("SELECT itemName,price FROM Item i WHERE i.restaurants=:restaurant_id")
	//List<Item> findItemByRestaurants(@Param("restaurant_id") int restaurantId);
	
	List<Item> findByRestaurants_RestId(int restaurantId);

	Item findByItemId(int itemId);
}
