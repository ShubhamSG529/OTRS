package com.springpeople.dto;

import java.util.List;

public class RestaurantBillDto {
	private String userName;
	private String restName;
	private String restAddress;
	private String orderTime;
	private String orderDate;
	private int tableNo;
	private List<ItemDto> itemdto;
	private int totalAmount;

	public RestaurantBillDto() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getTableNo() {
		return tableNo;
	}

	public void setTableNo(int tableNo) {
		this.tableNo = tableNo;
	}

	public List<ItemDto> getItemdto() {
		return itemdto;
	}

	public void setItemdto(List<ItemDto> itemdto) {
		this.itemdto = itemdto;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "RestaurantBillDto [userName=" + userName + ", restName=" + restName + ", restAddress=" + restAddress
				+ ", orderTime=" + orderTime + ", tableNo=" + tableNo + ", itemdto=" + itemdto + ", totalAmount="
				+ totalAmount + "]";
	}
}
