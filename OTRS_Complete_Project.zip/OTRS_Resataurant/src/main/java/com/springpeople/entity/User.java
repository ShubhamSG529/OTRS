package com.springpeople.entity;

import java.util.Set;

public class User {
	private int userId;
	private String userEmail;
	private String userContact;
	private String userPassword;
	private String userName;
	private int active = 1;
	private Set<Role> roles;

	public User() {
		super();
	}

	public User(String userName, String userEmail, String userContact, String userPassword) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.userContact = userContact;
		this.userPassword = userPassword;
	}

	public User(User users) {
		this.active = users.getActive();
		this.userEmail = users.getUserEmail();
		this.roles = users.getRoles();
		this.userName = users.getUserName();
		this.userId = users.getUserId();
		this.userPassword = users.getUserPassword();
	}

	public User(int userId) {
		this.userId = userId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserContact() {
		return userContact;
	}

	public void setUserContact(String userContact) {
		this.userContact = userContact;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userEmail=" + userEmail + ", userContact=" + userContact
				+ ", userPassword=" + userPassword + ", userName=" + userName + ", active=" + active + ", roles="
				+ roles + "]";
	}
}
