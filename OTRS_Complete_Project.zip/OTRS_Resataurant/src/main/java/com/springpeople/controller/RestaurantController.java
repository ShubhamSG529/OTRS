package com.springpeople.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.dto.RestaurantBillDto;
import com.springpeople.entity.Item;
import com.springpeople.entity.Restaurant;
import com.springpeople.service.ItemService;
import com.springpeople.service.RestaurantService;

@RestController
@CrossOrigin
public class RestaurantController {

	@Autowired
	RestaurantService restaurantService;

	@Autowired
	ItemService itemService;

	@RequestMapping(value = "/restaurants", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Restaurant>> getRestaurants() {
		System.out.println("RestaurantController-getRestaurants");
		List<Restaurant> allRestaurants = restaurantService.getAllRestaurants();
		System.out.println("allRestaurants: " + allRestaurants);
		if (allRestaurants.size() != 0)
			return new ResponseEntity<List<Restaurant>>(allRestaurants, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<Restaurant>>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/restaurant/{restaurant_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Restaurant> getSpecificRestaurant(@PathVariable("restaurant_id") int restaurantId) {
		System.out.println("RestaurantController-getSpecificRestaurant");
		Restaurant restaurant = restaurantService.getRestaurant(restaurantId);
		System.out.println("getSpecificRestaurant: " + restaurant);
		if (restaurant != null)
			return new ResponseEntity<Restaurant>(restaurant, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<Restaurant>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/restaurant/{restaurant_id}/items", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Item>> getAllRestaurantItems(@PathVariable("restaurant_id") int restaurantId) {
		System.out.println("RestaurantController-getAllRestaurantItems :" + restaurantId);
		List<Item> items = itemService.getItemsByRestaurantId(restaurantId);
		if (items.size() != 0)
			return new ResponseEntity<List<Item>>(items, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<List<Item>>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/order/generate_bill/{user_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestaurantBillDto> generateBill(@PathVariable("user_id") int userId,@RequestParam("access_token") String accessToken) {
		System.out.println("RestaurantController-generateBill");
		System.out.println("accessToken:"+accessToken);
		RestaurantBillDto restaurantBillDto = restaurantService.generateOrderBill(userId,accessToken);
		if (restaurantBillDto != null)
			return new ResponseEntity<RestaurantBillDto>(restaurantBillDto, HttpStatus.ACCEPTED);
		else
			return new ResponseEntity<RestaurantBillDto>(HttpStatus.NOT_FOUND);
	}
}
