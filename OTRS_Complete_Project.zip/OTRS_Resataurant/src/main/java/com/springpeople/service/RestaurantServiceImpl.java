package com.springpeople.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.springpeople.dto.ItemDto;
import com.springpeople.dto.RestaurantBillDto;
import com.springpeople.entity.Item;
import com.springpeople.entity.OrderedItem;
import com.springpeople.entity.Restaurant;
import com.springpeople.entity.User;
import com.springpeople.repository.ItemRepository;
import com.springpeople.repository.RestaurantRepository;

@Service
public class RestaurantServiceImpl implements RestaurantService {
	@Autowired
	RestaurantRepository restaurantRepository;

	@Autowired
	ItemRepository itemRepository;

	@Override
	public List<Restaurant> getAllRestaurants() {
		List<Restaurant> allRestaurants = restaurantRepository.findAll();
		if (allRestaurants.size() != 0) {
			return allRestaurants;
		}
		return null;
	}

	@Override
	public Restaurant getRestaurant(int restaurantId) {
		Restaurant restaurant = restaurantRepository.findByRestId(restaurantId);
		if (restaurant != null) {
			return restaurant;
		}
		return null;
	}

	@Override
	public RestaurantBillDto generateOrderBill(int userId,String accessToken) {
		List<OrderedItem> orderedItemList = getOrderedItemObject(userId,accessToken);
		System.out.println("generateOrderBill orderedItemList: "+orderedItemList);
		RestaurantBillDto restaurantBillDto = orderDetailsDtoLayer(orderedItemList);
		if (restaurantBillDto != null) {
			return restaurantBillDto;
		} else {
			return null;
		}
	}

	private RestaurantBillDto orderDetailsDtoLayer(List<OrderedItem> orderedItemList) {
		System.out.println(orderedItemList);
		Restaurant restaurant = restaurantRepository.findByRestId(orderedItemList.get(0).getRestaurantId());
		System.out.println("RestaurantBillDto: "+restaurant);
		User user = getUserByUserId(orderedItemList.get(0).getUserId());
		System.out.println("RestaurantBillDto: "+user);
		String userName = user.getUserName();
		String restName = restaurant.getRestName();
		String restAddress = restaurant.getRestAddress();

		List<ItemDto> itemdto = new ArrayList<ItemDto>();
		int totalAmount = 0;

		for (int i = 0; i < orderedItemList.size(); i++) {
			Item item = itemRepository.findByItemId(orderedItemList.get(i).getItemId());
			ItemDto itemDto = new ItemDto();
			itemDto.setItemId(item.getItemId());
			itemDto.setItemName(item.getItemName());
			itemDto.setItemPrice(item.getPrice());
			itemDto.setItemQuantity(orderedItemList.get(i).getQuantity());
			itemdto.add(itemDto);
			totalAmount += item.getPrice() * orderedItemList.get(i).getQuantity();
		}

		RestaurantBillDto restaurantBillDto = new RestaurantBillDto();
		restaurantBillDto.setUserName(userName);
		restaurantBillDto.setRestName(restName);
		restaurantBillDto.setRestAddress(restAddress);
		restaurantBillDto.setOrderTime(orderedItemList.get(0).getTime());
		restaurantBillDto.setOrderDate(orderedItemList.get(0).getDate());
		restaurantBillDto.setTableNo(orderedItemList.get(0).getTableNo());
		restaurantBillDto.setItemdto(itemdto);
		restaurantBillDto.setTotalAmount(totalAmount);

		return restaurantBillDto;
	}

	private List<OrderedItem> getOrderedItemObject(int userId,String accessToken) {
		List<OrderedItem> orderedItemList = new ArrayList<OrderedItem>();
		
		try {
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet("http://localhost:7071/order/bill/" + userId+"?access_token="+accessToken);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				System.out.println("List<OrderedItem>: "+line);
				int start = 0;
				int end = 0;
				int size = line.length() - 3;
				while (end <= size) {
					start = line.indexOf("{", end);
					end = line.indexOf("}", start);
					String subString = line.substring(start, end) + "}";

					Gson gson = new Gson();
					OrderedItem orderedItem = gson.fromJson(subString, OrderedItem.class);
					orderedItemList.add(orderedItem);
				}
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (UnsupportedOperationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return orderedItemList;
	}

	public User getUserByUserId(int userId) {
		User user = null;
		try {
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet("http://localhost:7072/user/" + userId);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				Gson gson = new Gson();
				user = gson.fromJson(line, User.class);
				System.out.println("getUserByUserId JSON: " + user);
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (UnsupportedOperationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return user;
	}
}
