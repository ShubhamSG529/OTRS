package com.springpeople.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.entity.Item;
import com.springpeople.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemRepository itemRepository;

	@Override
	public List<Item> getItemsByRestaurantId(int restaurantId) {
		List<Item> items = itemRepository.findByRestaurants_RestId(restaurantId);
		System.out.println("items:   " + items);

		if (items != null) {
			return items;
		} else {
			return null;
		}
	}

}
