package com.springpeople.service;

import java.util.List;

import com.springpeople.entity.Item;

public interface ItemService {
	List<Item> getItemsByRestaurantId(int restaurantId);
}
