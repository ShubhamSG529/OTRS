INSERT INTO item (item_name,price) VALUES ("Paneer Tikka",230),("Chicken Masala",190),("Chicken Biryani",180),("Veg Biryani",150);
INSERT INTO restaurant (image_path,rest_address,rest_contact,rest_name) 
VALUES
("images/restaurant1.jpg","Bangalore Metropolitan Task Force","1111111111","Granny - Elegant Restaurant & Cafe"),
("images/restaurant2.jpg","The Address Makers","2222222222","Luxury Simple Restaurant Parallax"),
("images/restaurant3.jpg","CMS Computers Ltd. Bangalore.","3333333333","Hot-meal Restaurant and Food Corner"),
("images/restaurant4.jpg","India Post","4444444444","Entrey's - Minimal HTML Template for Restaurants, Cafe, Hotels & Hostels");

INSERT INTO restaurant_items (restaurants_rest_id,items_item_id) VALUES (1,1),(1,4),(1,3),(2,1),(2,4),(2,3),(3,2),(3,3),(4,2),(4,3);






