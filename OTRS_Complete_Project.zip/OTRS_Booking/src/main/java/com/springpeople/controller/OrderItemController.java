package com.springpeople.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.entity.OrderedItem;
import com.springpeople.service.OrderedItemService;

@RestController
@CrossOrigin
public class OrderItemController {

	@Autowired
	OrderedItemService orderedItemService;

	/*
	 * item_details - >(item_id-qnty=item_id-qnty=) (1-0=4-0=)
	 */
	@RequestMapping(value = "/place_order/{restaurant_id}/{table_no}/{item_details}/{user_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> order(@PathVariable("restaurant_id") int restaurantId,
			@PathVariable("table_no") int tableNo, @PathVariable("item_details") String itemDetails,
			@PathVariable("user_id") int userId) {
		System.out.println("OrderItemController-order");
		System.out.println("restaurantId: " + restaurantId + " tableNo: " + tableNo + " userId: " + userId
				+ " itemDetails :" + itemDetails);
		boolean flag = orderedItemService.placeOrder(restaurantId, tableNo, itemDetails, userId);
		System.out.println("flag: "+flag);
		//String userEmail = userService.getUserById(new User(userId)).getUserEmail();

		if (flag) {
			/*String message = "Order Placed";
			String toEmail = userEmail;
			boolean send = EmailSender.send(message, toEmail);
			System.out.println("send: " + send);*/
			return new ResponseEntity<String>("Order Placed", HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<String>("Please Select any Dish", HttpStatus.NOT_FOUND);// #404
		}
	}

	@RequestMapping(value = "/order/bill/{user_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<OrderedItem>> generateBill(@PathVariable("user_id") int userId) {
		System.out.println("OrderItemController-generateBill");
		List<OrderedItem> orderedItem = orderedItemService.generateUserBill(userId);
		System.out.println("/order/bill/: "+orderedItem);
		if (orderedItem != null) {
			return new ResponseEntity<List<OrderedItem>>(orderedItem, HttpStatus.ACCEPTED);// #202
		} else {
			return new ResponseEntity<List<OrderedItem>>(HttpStatus.NOT_FOUND);// #404
		}

	}

	@RequestMapping(value = "/public")
	public ResponseEntity<String> publicData() {
		System.out.println("OrderItemController-publicData");
		return new ResponseEntity<String>("public !!", HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/private")
	public ResponseEntity<String> privateData() {
		System.out.println("OrderItemController-privateData");
		return new ResponseEntity<String>("private !!", HttpStatus.ACCEPTED);
	}
}
