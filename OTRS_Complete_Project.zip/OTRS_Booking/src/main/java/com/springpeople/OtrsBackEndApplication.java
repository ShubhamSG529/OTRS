package com.springpeople;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtrsBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtrsBackEndApplication.class, args);
	}
}
