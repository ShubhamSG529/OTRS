package com.springpeople.service;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.entity.OrderedItem;
import com.springpeople.repository.OrderedItemRepository;

@Service
public class OrderedItemServiceImpl implements OrderedItemService {
	@Autowired
	OrderedItemRepository orderedItemRepository;

	/*
	 * item_details - >(item_id-qnty;item_id-qnty;) (1-0;4-0;)
	 */
	@Override
	public boolean placeOrder(int restaurantId, int tableNo, String itemDetails, int userId) {
		boolean flag = false;
		String[] item_object = itemDetails.split("=");
		for (int i = 0; i < item_object.length; i++) {
			String[] item = item_object[i].split("-");
			int itemId = 0;
			int itemQuantity = 0;
			try {
				itemId = Integer.parseInt(item[0]);
				itemQuantity = Integer.parseInt(item[1]);
				System.out.println("itemId " + itemId + " itemQuantity: " + itemQuantity);
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
			}
			if (itemId != 0 && itemQuantity != 0) {
				OrderedItem orderedItem = new OrderedItem();

				orderedItem.setRestaurantId(restaurantId);
				orderedItem.setTableNo(tableNo);
				orderedItem.setUserId(userId);
				orderedItem.setItemId(itemId);
				orderedItem.setQuantity(itemQuantity);
				System.out.println("orderedItem : " + orderedItem);
				OrderedItem saveOrderedItem = orderedItemRepository.save(orderedItem);
				System.out.println(saveOrderedItem);

				if (saveOrderedItem != null) {
					flag = true;
				}
			}
		}

		return flag;
	}

	@Override
	public List<OrderedItem> generateUserBill(int userId) {
		List<OrderedItem> allOrderedItems = orderedItemRepository.findByUserId(userId);
		for (int i = 0; i < allOrderedItems.size(); i++) {
			Timestamp orderTime = allOrderedItems.get(i).getOrderTime();
			Date dte = new Date(orderTime.getTime());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String date = formatter.format(dte);
			SimpleDateFormat formatterTime = new SimpleDateFormat("hh:mm a");
			String time = formatterTime.format(dte);

			allOrderedItems.get(i).setDate(date);
			allOrderedItems.get(i).setTime(time);
		}
		System.out.println("allOrderedItems: " + allOrderedItems);

		if (allOrderedItems.size() != 0) {
			return allOrderedItems;
		} else {
			return null;
		}
	}
}
