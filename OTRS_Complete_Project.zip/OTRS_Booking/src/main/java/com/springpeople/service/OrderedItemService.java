package com.springpeople.service;

import java.util.List;

import com.springpeople.entity.OrderedItem;

public interface OrderedItemService {

	boolean placeOrder(int restaurantId, int tableNo, String itemDetails, int userId);

	public List<OrderedItem> generateUserBill(int userId);

}
